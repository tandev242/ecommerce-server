import { createGlobalStyle } from "styled-components";

export const GlobalStyles = createGlobalStyle`
    *,
    *::affter,
    *::before {
        box-sizing: boxder-box; 
    }

    body {
        background: #EFEFEF;
        font-size: 14px;
        color: #333333;
        width: 100%;
        height: 100vh;
        margin: 0;
        padding: 0;
        font-family: 'Roboto', sans-serif;
        //transition: all 0.25s linear; 
    }
`;
//gitlab
//SƠn Đảm đại

