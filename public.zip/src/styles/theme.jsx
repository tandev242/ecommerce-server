export const Theme = {
    mainColor: '#EE4D2D',
    textColorDefaul: '#333333',
    textColorBrown: '#555555CC',
    textColorBlack: '#000000DE',
    textColorWhite: '#FFFFFF',
    textColorBlue: '#0055AA',
    textActionColor: '#0055AA',
    lineColor: "rgba(0, 0, 0, 0.2)",
    backGroundBrown: "#EFEFEF",
    backGroundWhite: "#ffffff",
    boxShadowColor: "#888",
    btnPrimaryColorHover: "#E96A50"
} 