import React,{useState,useEffect} from "react";
import styled from "styled-components";
import { MdEdit } from 'react-icons/md'
import { Link } from "react-router-dom";

const Container = styled.div`
  width: 170px;
  height: 85px;
  display: flex;
  flex-direction: row;
  align-items: center;
  border-bottom: 1px solid ${({theme}) => theme.lineColor};
`
const Wrapper = styled.section`
  margin-left: 15px !important;
`

const ProfileImage = styled.img`
  height: 3.2rem;
  width: 3.2rem;
  border-radius: 2rem;
  cursor: pointer;
`

const ProfileName = styled.h1`
  font-size: 14px;
  font-weight: 600;
`

const FrofileAction = styled.span`
  color: ${({theme}) => theme.textColorBrown};
  cursor: pointer;
  font-weight: 500;
`

const CssEditIcon = {"fontSize": "14px"}

const ProfileNavbar = () => {
  const [error, setError] = useState(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [profile,setProfile] = useState([]);
    useEffect(()=> { 
        fetch("../../profiledb.json")
        .then(res => res.json())
        .then(
          (result) => {
            setIsLoaded(true);
            setProfile(result);
          },
          (error) => {
            setIsLoaded(true);
            setError(error);
          }
        )
  },[])

  if(error) {
    return <div>Error: {error.message}</div>;
  }
  else if (!isLoaded) {
    return <div>Loading...</div>;
  } 
  else {
    return(
      <React.Fragment>
        {profile.map(item => (
          <Container key={item.id}>
            <Link to="account/profile"><ProfileImage src={item.avatar}/></Link>
            <Wrapper>
                <ProfileName>{item.nameLogin}</ProfileName>
                <Link to="account/profile"><FrofileAction><MdEdit style={CssEditIcon}/>Sửa Hồ Sơ</FrofileAction></Link>
            </Wrapper>
          </Container>
          ))}
      </React.Fragment>
    )
  }
}

export default ProfileNavbar