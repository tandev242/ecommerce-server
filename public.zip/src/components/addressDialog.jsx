import React from "react";
import styled from "styled-components";

const Background = styled.div`
  width: 100vw;
  height: 100%;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  position: fixed;
  display: flex;
  justify-content: center;
  z-index: 1000;
  align-items: center;
`;

const DialogWrapper = styled.div`
  width: 450px;
  height: 320px;
  box-shadow: 0 5px 16px rgba(0, 0, 0, 0.2);
  background: #fff;
  color: #000;
  position: relative;
  border-radius: 5px;
  padding: 25px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;
const Title = styled.h5`
  font-weight: 100;
  padding-bottom: 10px;
`;

const Item = styled.div`
  margin-bottom: 15px;
  display: flex;
  justify-content: space-between;
`;

const Input = styled.input`
  height: 35px;
  width: 195px;
  background-color: ${({ theme }) => theme.backGroundWhite};
  border: 1px solid ${({ theme }) => theme.lineColor};
  border-radius: 2px;
  font-size: 14px;
  padding-left: 10px;
`;
const LongInput = styled(Input)`
  width: 450px;
`;
const AddressInput = styled.textarea`
  resize: none;
  height: 70px;
  width: 450px;
  background-color: ${({ theme }) => theme.backGroundWhite};
  border: 1px solid ${({ theme }) => theme.lineColor};
  border-radius: 2px;
  font-size: 14px;
  font-family: "Roboto", sans-serif;
  padding: 10px;
`;

const ButtonWhite = styled.button`
  height: 40px;
  width: 170px;
  font-size: 14px;
  background-color: ${({ theme }) => theme.backGroundWhite};
  cursor: pointer;
  border: 1px solid ${({ theme }) => theme.lineColor};
  border-radius: 2px;
  margin-left: 20px;

  :hover {
    background-color: ${({ theme }) => theme.backGroundBrown};
  }
`;

const ButtonPrimary = styled(ButtonWhite)`
  background-color: ${({ theme }) => theme.mainColor};
  border: none;
  margin-right: 20px;
  color: ${({ theme }) => theme.textColorWhite};

  :hover {
    background-color: ${({ theme }) => theme.btnPrimaryColorHover};
  }
`;

const AddressDialog = (props) => {
  return (
    <React.Fragment>
      {props.showAddressDialog ? (
        <Background>
          <DialogWrapper>
            <Title>{props.formMode ? "Thêm" : "Cập nhật"} địa chỉ</Title>
            <Item>
              <Input placeholder="Họ và tên" 
              onChange={props.changeFullName} defaultValue={props.fullName} />
              <Input placeholder="Số điện thoại" 
              onChange={props.changePhone} defaultValue={props.phone} />
            </Item>
            <Item>
              <LongInput
                placeholder="Tỉnh/Thành phố, Quận/Huyện, Phường/Xã"
                onChange={props.changeAddress} defaultValue={props.address}
              />
            </Item>
            <Item>
              <AddressInput
                placeholder="Địa chỉ cụ thể"
                onChange={props.changeAddressNote} defaultValue={props.addressNote}
              />
            </Item>
            <Item> 
              <ButtonWhite
                onClick={() => props.setShowAddressDialog((prev) => !prev)}
              >
                Trở Lại
              </ButtonWhite>
              <ButtonPrimary type="submit" onClick={props.addAddress}>{props.formMode ? 'Thêm' : 'Cập nhật'}</ButtonPrimary>
            </Item>
          </DialogWrapper>
        </Background>
      ) : null}
    </React.Fragment>
  );
};

export default AddressDialog;
