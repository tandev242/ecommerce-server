import React from "react";
import styled from "styled-components";
import { KeyboardArrowRight } from "@material-ui/icons";
import { Link } from "react-router-dom";

const Container = styled.div`
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  transform: translateZ(0);
  z-index: 500;
  background: #fff;
  transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0.5px 0.5px 5px 0.5px #ccc;
`;

const NavbarWrapper = styled.div`
  min-width: inherit;
  height: inherit;
  z-index: 400;
  background: transparent;
  position: relative;
  border-bottom: 2px solid #ccc;
`;

const ContainerNavbar = styled.nav`
  width: inherit;
  max-width: 1600px;
  color: #000;
  margin-right: auto;
  margin-left: auto;
  display: flex;
  align-items: center;
  padding: 15px 0px;
  justify-content: space-between;
`;

const LeftNav = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex: 1;
`;
const LogoHeader = styled.img`
  width: 180px;
  cursor: pointer;
`;

const PagePresent = styled.div`
  font-style: normal;
  font-weight: 500;
  font-size: 18px;
  line-height: 18px;

  color: rgba(0, 0, 0, 0.75);
`;
const CenterSpace = styled.div`
  flex: 1;
`;

const RightNav = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex: 1;
`;

const UserImg = styled.img`
  fill: #fff;
  width: 40px;
  height: 40px;
  background-color: #fff;
  cursor: pointer;
  border-radius: 50%;
`;

const UserName = styled.span`
  color: rgba(0, 0, 0, 0.75);
  font-weight: 500;
  font-size: 18px;
  line-height: 18px;
  margin: 0 15px;
  position: relative;

  &::after {
    content: "";
    height: 1.4rem;
    width: 0;
    border-right: 2px solid #ccc;
    position: absolute;
    right: -15px;
    top: calc(50%-10px);
  }
`;

const HeaderIcon = styled.img`
  width: 16px;
  cursor: pointer;
`;

const CssKeyboardArrowRight = {
  height: "30px",
  width: "35px",
  color: "gray",
}

const Header = () => {
  return (
    <Container>
      <NavbarWrapper>
        <ContainerNavbar>
          <LeftNav>
            <LogoHeader src="https://kenhquanly.shopee.vn/images/logo_32_vn.df7ecbd0.png" />
            <KeyboardArrowRight style={CssKeyboardArrowRight} />
            <Link to="/">
              <PagePresent>Trang Chủ</PagePresent>
            </Link>
          </LeftNav>
          <CenterSpace></CenterSpace>
          <RightNav>
            <UserImg src="https://scontent.xx.fbcdn.net/v/t1.15752-9/260973034_620697476041810_7358295328192465228_n.jpg?stp=dst-jpg_p206x206&_nc_cat=103&ccb=1-7&_nc_sid=aee45a&_nc_ohc=Gq1GzLV0CYgAX9XLFBD&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_AVJyltMWzSreRu7oIMcMcbLg-knSJRRvF3--F0Hzpg07oA&oe=63052D3E" />
            <UserName>19110001</UserName>
            <HeaderIcon
              style={{ margin: "0 15px 0 15px" }}
              src="https://scontent.xx.fbcdn.net/v/t1.15752-9/294873161_772782744034389_5604466774440638221_n.png?stp=cp0_dst-png&_nc_cat=101&ccb=1-7&_nc_sid=aee45a&_nc_ohc=RtUGTbBuklEAX9IXnpg&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_AVIYe6P85mQWO7HD_kt0D46EY370rgo6ieUYGMqZFnfkuw&oe=631214AA" />
            <HeaderIcon src="https://scontent.xx.fbcdn.net/v/t1.15752-9/291499610_428115899243520_6903573953858751534_n.png?stp=cp0_dst-png&_nc_cat=110&ccb=1-7&_nc_sid=aee45a&_nc_ohc=1fRK8u_OOOsAX8zrIg7&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_AVIpx-vnOFegxFZXHtIctWzXEMRNZgvKp7fKi6kcM0nXpA&oe=6310904D" />
          </RightNav>
        </ContainerNavbar>
      </NavbarWrapper>
    </Container>
  );
};

export default Header;
