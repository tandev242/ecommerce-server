import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import Table from "react-bootstrap/Table";
import styled from "styled-components";
import Header from "../../../components/NaHeAdmin/Header";
import LeftNavbar from "../../../components/NaHeAdmin/LeftNavbar";

const Container = styled.div``;
function BrandManagement() {
    const [data, setData] = useState([]);
    useEffect(() => {
        fetch("http://jsonplaceholder.typicode.com/users")
            .then((res) => res.json())
            .then((data) => {
                setData(data);
            });
    });
    return (
        <Container>
            <Header />
            <LeftNavbar />
            <div
                className="container"
                style={{
                    marginLeft: "280px",
                    marginRight: "0",
                    display: "flex",
                    flex: "flex-end",
                    flexDirection: "column",
                }}
            >
                <Link to="/addtrademark">
                    <a style={{
                        color: "red",
                        fontsize: "40px",
                    }}>
                        +Thêm thương hiệu
                    </a>
                </Link>
                <h1>Thông tin các thương hiệu </h1>
                <Table
                    style={{
                        width: "90%",
                    }}
                    className="table table-bordered"
                >
                    <tbody className="thead-dark">
                        <tr>
                            <th>Id</th>
                            <th>Tên thương hiệu</th>
                            <th>Email thương hiệu</th>
                            <th>Địa Chỉ</th>
                            <th>Website</th>
                            <th>Số ĐT</th>
                            <th>Delete</th>
                            <th></th>
                        </tr>
                    </tbody>
                    {data.map((item) => (
                        <tbody key={item.id}>
                            <tr>
                                <td>{item.id}</td>
                                <td>{item.name}</td>
                                <td>{item.email}</td>
                                <td>{item.address.street}</td>
                                <td>{item.website}</td>
                                <td>{item.phone}</td>
                                <td>
                                    <label
                                        className="badge badge-danger"
                                        onClick={() => this.deleteItem(item.name)}
                                    >
                                        Delete
                                    </label>
                                </td>
                                <td>
                                    <label className="badge badge-info">
                                        Xem Chi Tiết
                                    </label>
                                </td>
                            </tr>
                        </tbody>
                    ))}
                </Table>
            </div>
        </Container>
    );
}

export default BrandManagement;