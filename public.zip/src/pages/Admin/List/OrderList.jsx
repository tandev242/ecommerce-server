import React from "react";
import HomeUser from "../../../components/NaHeAdmin/order";
import styled from "styled-components";
import Header from "../../../components/NaHeAdmin/Header";
import LeftNavbar from "../../../components/NaHeAdmin/LeftNavbar";


const Wrapper = styled.section`
  padding-left: 290px;
  margin-bottom: 36px;
  display: flex;
  flex-direction: row;
`

const Orderlist = () => {
    return (
        <div>
            <Header />
            <LeftNavbar />
            <Wrapper>
                <HomeUser />
            </Wrapper>
        </div>
    )
}

export default Orderlist
