import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import Table from "react-bootstrap/Table";
import styled from "styled-components";
import Header from "../../../components/NaHeAdmin/Header";
import LeftNavbar from "../../../components/NaHeAdmin/LeftNavbar";
import { Link } from "react-router-dom";

const Container = styled.div``;
function ProductList() {
  const [data, setData] = useState([]);
  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then((res) => res.json())
      .then((data) => {
        setData(data);
      });
  });

  return (
    <Container>
      <Header />
      <LeftNavbar />
      <div
        className="container"
        style={{
          marginLeft: "280px",
          marginRight: "0",
          display: "flex",
          flex: "flex-end",
          flexDirection: "column",
        }}
      >
        <Link to="/addproduct">
          <a style={{
            color: "red",
            fontsize: "40px",
          }}>
            +Thêm sản phẩm
          </a>
        </Link>
        <h1>Danh sách sản phẩm </h1>
        <Table
          style={{
            width: "90%",
          }}
          className="table table-bordered"
        >
          <tbody className="thead-dark">
            <tr>
              <th>Id</th>
              <th>Tên sản phẩm</th>
              <th>Loại sản phẩm</th>
              <th>Giá</th>
              <th>Số lượng</th>
              <th>Hình ảnh</th>
              <th>Delete</th>
              <th></th>
            </tr>
          </tbody>
          {data.map((item) => (
            <tbody key={item.id}>
              <tr>
                <td>{item.id}</td>
                <td>{item.title}</td>
                <td>{item.category}</td>
                <td>{item.price}</td>
                <td>{item.rating.count}</td>
                <td>
                  <img style={{ width: 40 }} src={item.image} />
                </td>
                <td>
                  <label
                    className="badge badge-danger"
                    onClick={() => this.deleteItem(item.name)}
                  >
                    Delete
                  </label>
                </td>
                <td>
                  <label className="badge badge-info">
                    Xem Chi Tiết
                  </label>
                </td>
              </tr>
            </tbody>
          ))}
        </Table>
      </div>
    </Container>
  );
}

export default ProductList;
