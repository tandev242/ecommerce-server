import React from "react";
import '../../../css/Modal.css';

function Modal({ closeModal }) {
    return (
        <div className="modalBackground">
            <div className="modalContainer">
                <div className="modalTitle">
                    <h1>Sản phẩm đã được thêm vào giỏ hàng</h1>
                </div>
                <div>
                    <img style={{ width: 80, alignItems: "center", display: "flex", justifyItems: "center" }}
                        src="https://suminhchau.vn/wp-content/uploads/2018/05/icon-1.jpg"
                        className="modalImg"
                    />
                </div>
                <div className="modalFooter">
                    <button onClick={() => closeModal(false)} id="cancelBtn">Cancel</button>
                </div>
            </div>
        </div>
    )
}

export default Modal;