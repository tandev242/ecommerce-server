import React from "react";
import { createRef } from "react";
import { useState, useEffect } from "react";
import ProductReview from "./productReview";
import ProductEvaluate from "./productEvaluate";
import { Box } from "@mui/material";
import "../../../css/productDetail.css";
import Header from "../../../components/header";
import Footer from "../../../components/footer";
// import { Link } from 'react-router-dom';
import { collection, getDocs, query, where } from "firebase/firestore";
import { db } from "../../../firebase/firebase-config";
import Modal from './Modal';
import { useParams } from "react-router-dom";
import CloseIcon from '@mui/icons-material/Close';
// import axios from 'axios';



function ProductDetail() {
    const myRef = createRef();
    const [quantity, setQuantity] = useState(1);
    const [productList, setProductList] = useState([]);
    const [openModal, setOpenModal] = useState(false);
    const [model, setModel] = useState(false);
    const [tempimgSrc, setTempImgSrc] = useState('');
    // const [APIData, setAPIData] = useState([]);


    let idProduct = useParams();


    const handleIncrement = () => {
        if (quantity < 20) {
            setQuantity(quantity + 1)
        }
    }

    const handleDecrement = () => {
        if (quantity > 1) {
            setQuantity(quantity - 1)
        }
    }



    useEffect(() => {
        const colRef = collection(db, "productList");
        const q = query(colRef, where("id_product", "==", Number(idProduct.id)));
        getDocs(q).then((snapshot) => {
            let productList = [];
            snapshot.docs
                .forEach((doc) => {
                    productList.push({
                        id: doc.id,
                        ...doc.data(),
                    });
                    setProductList(productList);
                })
        });
    }, [idProduct]);

    // useEffect(() => {
    //     axios.get(`https://62e8fc93249bb1284eb7e8a8.mockapi.io/product__List`)
    //         .then((response) => {
    //             setAPIData(response.data);
    //         })
    // }, [])


    const getImg = (img) => {
        setTempImgSrc(img);
        setModel(true);
    }

    return (
        <React.Fragment>
            <Header />
            <div className="app">
                {
                    productList.map(item => (
                        <div className="details" key={item.id_product}>
                            <div className="big-img">
                                <img src={item.img[0]}
                                    alt="Snow"
                                    className="Selected"
                                />
                                <div className={model ? "model open" : "model"}>
                                    <img src={tempimgSrc} />
                                    <CloseIcon onClick={() => setModel(false)} />
                                </div>
                                <div className="thumb" ref={myRef}>
                                    {
                                        item.img.map((img, index) => (
                                            <img
                                                src={img}
                                                alt=""
                                                key={index}
                                                onClick={() => getImg(img)}
                                            />
                                        ))
                                    }
                                </div>
                            </div>
                            <div className="box">
                                <div className="row">
                                    <h2>{item.title}</h2>
                                </div>
                                <div className="flex flex-column _4ZZZt9">
                                    <div className="flex items-center">
                                        <div className="flex items-center X1ceUd">
                                            <div className="CDN0wz">{item.price}.000đ</div>
                                            <div className="flex items-center">
                                                <div className="pmmxKx">{item.price * (100 - item.saleOff) / 100}.000đ</div>
                                                <div className="lTuS3S">Giảm{item.saleOff}%</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="PvQTP">...</div>
                                        <div className="fTn0aD">Gì cũng rẻ</div>
                                        <div className="x1-hIE">Giá tốt nhât
                                            so với các sản phẩm cùng loại trên shopee!</div>
                                    </div>
                                </div>

                                <div>
                                    <p>Vận Chuyển : <img
                                        src="https://deo.shopeemobile.com/shopee/shopee-pcmall-live-sg/pdp/1cdd37339544d858f4d0ade5723cd477.png"
                                        alt=""
                                        width="25" height="15" className="freeShip" />
                                        Miễn phí vận chuyển
                                    </p>
                                </div>

                                <div className="colors">
                                    <label className="font">
                                        Color: {
                                            item.color.map((color, index) => (
                                                <button key={index}>{color}</button>
                                            ))
                                        }
                                    </label>
                                </div>

                                <div className="size">
                                    <label className="font">
                                        Size: {
                                            item.size.map((size, index) => (
                                                <button key={index}>{size}</button>
                                            ))
                                        }
                                    </label>
                                </div>

                                <Box className="product-quanlity">
                                    <Box className="product-quanlity__title">
                                        Số lượng
                                    </Box>
                                    <Box className="product-quanlity__groupInput">
                                        <button onClick={handleDecrement} className="amount">-</button>
                                        <input message={quantity} type="text" placeholder={quantity} className="text" />
                                        <button onClick={handleIncrement} className="amount">+</button>
                                    </Box>
                                </Box>
                                <button
                                    className="cart"
                                    onClick={() => {
                                        setOpenModal(true);
                                    }}
                                >
                                    Thêm Vào Giỏ Hàng
                                </button>
                                {openModal && <Modal closeModal={setOpenModal} />}
                                <button className="buy">Mua Ngay</button>
                            </div>
                        </div>
                    ))
                },
                {
                    <ProductEvaluate />
                },
                {
                    <Box className="productSpecification">
                        <Box className="productSpecification__title">
                            CHI TIẾT SẢN PHẨM
                        </Box>
                        <Box className="productSpecification__table">
                            {
                                productList.map(item => (
                                    <table className="product__table" key={item.id_product}>
                                        <tbody>
                                            <tr className="product__tr">
                                                <td className="product__td1">Dịp</td>
                                                <td className="product__td2">{item.occasion}</td>
                                            </tr>
                                            <tr className="product__tr">
                                                <td className="product__td1">Chất liệu</td>
                                                <td className="product__td2">{item.material}</td>
                                            </tr>
                                            <tr className="product__tr">
                                                <td className="product__td1">Xuất xứ</td>
                                                <td className="product__td2">{item.country}</td>
                                            </tr>
                                            <tr className="product__tr">
                                                <td className="product__td1">Đã bán</td>
                                                <td className="product__td2">{item.sold} K</td>
                                            </tr>
                                            <tr className="product__tr">
                                                <td className="product__td1">Kho hàng</td>
                                                <td className="product__td2">{item.wareHouse}</td>
                                            </tr>
                                            <tr className="product__tr">
                                                <td className="product__td1">Gửi từ</td>
                                                <td className="product__td2">{item.sentFrom}</td>
                                            </tr>
                                            <tr className="product__tr">
                                                <td className="product__td1">Loại</td>
                                                <td className="product__td2">{item.categories}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                ))
                            }
                        </Box>
                    </Box>
                },
                <ProductReview />
            </div>
            <Footer />
        </React.Fragment>
    );
};

export default ProductDetail;