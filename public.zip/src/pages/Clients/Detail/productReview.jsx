import React from "react";
import { useState } from "react";
import ReactStars from "react-rating-stars-component";


export default function ProductReview() {
    const [data, setData] = useState([1, 2, 3, 4, 5]);

    return (
        <div className="comment__commentStore">
            <div className="title__listStore">
                <h1>Bình luận</h1>
            </div>
            <div className="content__commentStore">
                {data.map((item) => (
                    <div className="content__area" key={item}>
                        <img src="https://scontent.fsgn16-1.fna.fbcdn.net/v/t1.6435-9/68782077_106383027397692_4463514427013988352_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=09cbfe&_nc_ohc=yIR-ixof00wAX-vue29&_nc_ht=scontent.fsgn16-1.fna&oh=00_AT_y1CgUi28dCinLsU6bhPpJobBHCHqhaMEF0GfPC7O4Eg&oe=62FDC0EB" />
                        <div className="content">
                            <div className="nameUser">
                                <h3>Son Lam</h3>
                            </div>
                            <div className="commentUser">
                                <div className="__dateAndCancel">
                                    <p>3/5/2021</p>
                                    
                                </div>
                                <div className="__rating">
                                    <ReactStars
                                        {...{
                                            size: 25,
                                            value: 4,
                                            edit: false,
                                            isHalf: true
                                        }}
                                    />
                                </div>
                                <div className="__comment">
                                    <p>
                                        Đây là một sản phẩm tốt
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}