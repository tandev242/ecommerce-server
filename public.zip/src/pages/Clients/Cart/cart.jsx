import { Add, KeyboardArrowUp, Remove } from "@material-ui/icons";
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import Header from "../../../components/header";
import Footer from "../../../components/footer";
import Checkbox from "./checkbox";
import RecommendProducts from "../Home/homeRecommendProducts/recommendProducts";
import { Link } from "react-router-dom";
import DeleteItem from "./deleteItem";
import { deleteProduct, getProductList, updateQuantityProduct } from "../../../data/productData";

const Container = styled.div`
  background-color: #f5f5f5;
`;

const Wrapper = styled.div`
  margin-right: auto;
  margin-left: auto;
  width: 1200px;
  display: flex;
  flex-direction: column;
  color: rgba(0, 0, 0, 0.8);
  padding-top: 20px;
`;

const FreeShip = styled.div`
  background-color: #fffefb;
  border: 1px solid rgba(224, 168, 0, 0.4);
  padding: 0.75rem 1rem;
  display: flex;
  align-items: center;
  margin-bottom: 0.625rem;
  border-radius: 2px;
`;

const LogoFreeShip = styled.img`
  width: 3%;
  height: 3%;
  margin-right: 5px;
`;

const FreeShipInfo = styled.div`
  font-weight: 450;
  font-size: 14px;
`;

const MiniNav = styled.div`
  display: flex;
  align-items: center;
  box-shadow: 0 1px 1px 0 rgb(0 0 0 / 5%);
  border-radius: 0.125rem;
  overflow: hidden;
  border-radius: 3px;
  height: 55px;
  font-size: 14px;
  background: #fff;
  text-transform: capitalize;
  margin-bottom: 12px;
  color: #888;
`;

const Product = styled.div`
  color: rgba(0, 0, 0, 0.8);
  width: 46.27949%;
`;

const Price = styled.div`
  width: 15.88022%;
  text-align: center;
`;

const Quantity = styled.div`
  width: 15.4265%;
  text-align: center;
`;

const Money = styled.div`
  width: 10.43557%;
  text-align: center;
`;

const Action = styled.div`
  width: 12.70417%;
  text-align: center;
`;

const Item = styled.div`
  box-shadow: 0 1px 1px 0 rgb(0 0 0 / 5%);
  border-radius: 0.125rem;
  overflow: hidden;
  background: #fff;
  margin-bottom: 10px;
`;

const ItemInfo = styled.div`
  margin-top: 0;
  padding: 16px 0;
  display: flex;
  align-items: center;
  color: rgba(0, 0, 0, 0.87);
`;

const ItemImage = styled.img`
  background-position: 50%;
  background-size: contain;
  background-repeat: no-repeat;
  width: 80px;
  height: 80px;
`;

const ItemInfoDetails = styled.div`
  display: flex;
  flex-direction: column;
  padding: 5px 20px 0 10px;
  font-size: 14px;
  width: 300.5px;
  line-height: 16px;
  overflow: hidden;
`;

const ItemName = styled.a`
  text-decoration: none;
  color: rgba(0, 0, 0, 0.87);
  font-weight: 500;
  display: block;
  margin-bottom: 5px;
  max-height: 32px;
  text-overflow: ellipsis;
  word-break: break-word;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
`;

const ItemShipping = styled.img`
  height: 18px;
  background-size: contain;
  background-repeat: no-repeat;
  width: 77%;
`;

const ItemType = styled.div`
  color: rgba(0, 0, 0, 0.54);
  display: flex;
  flex-direction: column;
  font-size: 0.875rem;
  margin-right: 10px;
  width: 17.24138%;
`;

const ItemInfoType = styled.div`
  display: flex;
  align-items: center;
  text-transform: capitalize;
  text-align: left;
`;

const ItemChosen = styled.div`
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: break-word;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  text-align: left;
  margin-top: 5px;
`;

const ItemPriceWrapper = styled.div`
  flex-direction: column;
  width: 15.88022%;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ItemPrice = styled.span`
  text-decoration: none;
  color: rgba(0, 0, 0, 0.87);
  display: block;
`;

const ItemQuantity = styled.div`
  display: flex;
  align-content: center;
  align-items: center;
  justify-content: center;
  width: 15.4265%;
`;

const Input = styled.input`
  width: 50px;
  height: 30px;
  font-size: 18px;
  font-weight: 400;
  border: 1px solid rgba(0,0,0,0.2);
  border-left: none;
  border-right: none;
  background-color: #fff;
  box-sizing: border-box;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: text;
  border-radius: 0;
  -webkit-appearance: none;
`;

const InputBtn = styled.div`
  width: 30px;
  height: 30px;
  border: 1px solid rgba(0,0,0,0.2);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
`

const ItemMoney = styled.div`
  width: 10.43557%;
  text-align: center;
  color: #ee4d2d;
`;

const Handle = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 12.70417%;
  flex-direction: column;
`;

const RemoveButton = styled.button`
  cursor: pointer;
  background: none;
  border: 0;
`;

const TotalPrice = styled.div`
  z-index: 2;
  position: -webkit-sticky;
  position: sticky;
  bottom: 0;
  display: grid;
  grid-template-columns: 1fr 20.3125rem 11.875rem;
  align-items: center;
  box-sizing: border-box;
  background: #fff;
  width: 100%;
  flex: 1;
  font-size: 1rem;
  margin-top: 0.75rem;

  &::before {
    content: "";
    position: absolute;
    top: -1.25rem;
    left: 0;
    height: 1.25rem;
    width: 100%;
    background: linear-gradient(transparent, rgba(0, 0, 0, 0.06));
  }
`;

const Voucher = styled.div`
  grid-column-start: 2;
  grid-column-end: 4;
  -ms-grid-column-span: 2;
  display: flex;
  align-items: center;
  padding: 0.75rem 0;
`;

const VoucherImage = styled.img`
  color: #ee4d2d;
  fill: currentColor;
  width: 1.3125rem;
  height: 1.25rem;
  display: inline-block;
  position: relative;
  padding-top: 4px;
`;

const VoucherTitle = styled.div`
  font-weight: 500;
  flex-shrink: 0;
  margin: 0 0.4rem;
`;

const VoucherSpace = styled.div`
  flex: 1;
`;

const EnterVoucher = styled.span`
  margin-right: 1.875rem;
  text-transform: capitalize;
  color: #05a;
  font-size: 0.875rem;
  white-space: nowrap;
  cursor: pointer;
`;

const Line = styled.div`
  grid-column-start: 1;
  grid-column-end: 4;
  -ms-grid-column-span: 3;
  border-top: 1px dashed rgba(0, 0, 0, 0.09);
`;

const Space = styled.div`
  display: flex;
  flex-direction: row-reverse;
  min-width: 58px;
  box-sizing: border-box;
  grid-column-start: 1;
  grid-column-end: 2;
  -ms-grid-column-span: 1;
  flex: 0 0 auto;
  padding: 16px 12px 16px 20px;
`;

const ShopeeCoin = styled.div`
  justify-content: flex-start;
  grid-column-start: 2;
  grid-column-end: 3;
  display: flex;
  align-items: center;
`;

const CoinImage = styled.img`
  width: 18px;
  height: 18px;
  flex: 0 0 auto;
  fill: none;
  display: inline-block;
  position: relative;
`;

const CoinTitle = styled.div`
  font-weight: 500;
  flex-shrink: 0;
  margin-left: 8px;
  font-size: 14px;
`;

const CoinAnnoun = styled.div`
  font-weight: 500;
  flex: 0 1 auto;
  color: #929292;
  font-size: 14px;
  margin-left: 17px;
`;

const CoinLogo = styled.img`
  opacity: 0.4;
  width: 14px;
  height: 14px;
  flex: 0 0 auto;
  fill: none;
  display: inline-block;
  margin-left: 5px;
  position: relative;
`;

const SalePrice = styled.div`
  display: flex;
  align-items: center;
  grid-column-start: 3;
  grid-column-end: 4;
  justify-content: flex-end;
  padding-right: 30px;
  font-weight: 500;
  color: #d0d0d0;
`;

const Total = styled.div`
  padding: 12px 0;
  grid-column-start: 1;
  grid-column-end: 4;
  -ms-grid-column-span: 3;
  display: flex;
  align-items: center;
  flex: 1;
  width: 100%;
  font-size: 1rem;
`;

const ChooseAll = styled.button`
  font-size: 1rem;
  text-transform: capitalize;
  cursor: pointer;
  background: 0;
  border: 0;
  overflow: visible;
  color: inherit;
  font: inherit;
  margin: 0;
`;

const ClearButton = styled.button`
  margin: 0 8px;
  background: 0;
  border: 0;
  -webkit-appearance: button;
  cursor: pointer;
  text-transform: none;
  overflow: visible;
  color: inherit;
  font: inherit;
`;

const SpaceSmall = styled.div`
  font-size: 1rem;
  visibility: visible;
`;

const SaveButton = styled.button`
  color: #ee4d2d;
  margin: 0 8px;
  max-width: 168px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  background: 0;
  border: 0;
  -webkit-appearance: button;
  cursor: pointer;
  text-transform: none;
  font: inherit;
`;

const Payment = styled.div`
  position: relative;
`;

const TotalPayment = styled.div``;

const TotalWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;

const TotalPricePayment = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-end;
  margin-left: 20px;
`;

const TotalMoneyTitle = styled.div`
  font-size: 16px;
  color: #222;
  line-height: 19px;
`;

const TotalMoney = styled.div`
  font-size: 24px;
  line-height: 28px;
  margin-left: 5px;
  color: #ee4d2d;
`;

const SavePayment = styled.div`
  font-size: 14px;
  margin-top: 1px;
  text-align: right;
`;

const SaveMoney = styled.span`
  padding-left: 24px;
  color: #ee4d2d;
  font-size: 14px;
  text-align: right;
`;

const BuyNowButton = styled.button`
  padding: 13px 36px;
  margin: 0 22px 0 15px;
  text-transform: capitalize;
  font-weight: 300;
  height: 2.5rem;
  box-sizing: border-box;
  font-size: 0.875rem;
  border-radius: 2px;
  width: 13.125rem;
  position: relative;
  overflow: visible;
  outline: 0;
  background: #ee4d2d;
  cursor: pointer;
  border: 0;
  line-height: 1;
  letter-spacing: 0;
  user-select: none;
  box-shadow: 0 1px 1px 0 rgb(0 0 0 / 9%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  transition: opacity 0.2s ease;

  &:hover {
    background: #f05d40;
  }
`;

const BuyNow = styled.span`
  width: 100%;
`;

const RecommendWrapper = styled.div`
  padding-bottom: 20px;
  background-color: #f5f5f5;
  width: 1200px;
  margin-left: auto;
  margin-right: auto;
`;

const NullCart = styled.div`
  margin-right: auto;
  margin-left: auto;
  width: 1200px;
  height: 21rem;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
`;

const NullCartLogo = styled.div`
  width: 6.75rem;
  height: 6.125rem;
  background-position: 50%;
  background-size: cover;
  background-repeat: no-repeat;
  background-image: url(https://deo.shopeemobile.com/shopee/shopee-pcmall-live-sg/cart/9bdd8040b334d31946f49e36beaf32db.png);
`;

const NullCartTitle = styled.div`
  color: rgba(0, 0, 0, 0.4);
  font-size: 0.875rem;
  line-height: 1rem;
  margin-top: 1.125rem;
  font-weight: 700;
`;

const NullCartLink = styled.a`
  margin-top: 1.0625rem;
  text-decoration: none;
  color: rgba(0, 0, 0, 0.87);
  display: block;
  cursor: pointer;
  background-color: transparent;
`;

const NullCartBuyNowButton = styled.button`
  padding: 0.625rem 2.625rem;
  position: relative;
  overflow: visible;
  outline: 0;
  background: #ee4d2d;
  cursor: pointer;
  border: 0;
  font-size: 0.875rem;
  font-weight: 300;
  line-height: 1;
  letter-spacing: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  transition: opacity 0.2s ease;
  border-radius: 2px;
  user-select: none;
  box-shadow: 0 1px 1px 0 rgb(0 0 0 / 9%);

  &:hover {
    background: #f05d40;
  }
`;

const NullCartBuyNowSpan = styled.div`
  font-size: 1rem;
  text-transform: capitalize;
  cursor: pointer;
  font-weight: 450;
  line-height: 1;
  color: #fff;
  user-select: none;
  letter-spacing: 0;
`;

function Cart() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [carts, setCarts] = useState([]);
  const [value, setCheckbox] = useState(false);
  const [showDeleteItem, setShowDeleteItem] = useState(false);
  const [productId, setProductId] = useState();
  const [itemName, setItemName] = useState('');
  let totalPrice = 0;

  const getList = async () => {
    try {
      setIsLoaded(true);
      const list = await getProductList();
      setCarts(list);
      setIsLoaded(false);
    }
    catch (error) {
      setIsLoaded(false);
    }
  }

  const deleteAddressHandle = async () => {
    try {
      await deleteProduct(productId);
      getList();
      setShowDeleteItem(prev => !prev);
    } catch (error) {
      throw error
    }
  }

  const handleIncrement = (id) => {
    setCarts(item =>
      item.map(
        (item) =>
          id === item.id ? ({ ...item, quantity: item.quantity + 1 }) : item
      )
    );
    updateQuantityProduct(id, "inc");
  }

  const handleDecrementBtn = (id, quantity, name) => {
    if (quantity === 1) {
      setShowDeleteItem(prev => !prev);
      setProductId(id);
      setItemName(name);
    }
    else {
      handleDecrement(id);
    }
  }

  const handleDecrement = (id) => {
    setCarts(item =>
      item.map(
        (item) =>
          (id === item.id ? ({ ...item, quantity: item.quantity - 1 }) : item)
      )
    );
    updateQuantityProduct(id, "dec");
  }

  const handleDeleteBtn = async (id) => {
    await deleteProduct(id);
    getList();
  }

  useEffect(() => {
    getList();
  }, []);

  return (
    <React.Fragment>
      <Header />
      <Container>
        {(isLoaded) ? (<NullCart><h5 style={{fontWeight: "500"}}>Loading...</h5></NullCart>): carts.length > 0 ? (
          <Wrapper>
            <FreeShip>
              <LogoFreeShip src="https://ikids.vn/wp-content/uploads/2019/04/FreeShip.png" />
              <FreeShipInfo>
                Nhấn vào mục Mã giảm giá ở cuối trang để hưởng miễn phí vận
                chuyển bạn nhé!
              </FreeShipInfo>
            </FreeShip>

            <MiniNav>
              <Checkbox
                value={value}
                checked={value}
                onChange={({ target }) => setCheckbox(!value)}
              />
              <Product>Sản Phẩm</Product>
              <Price>Đơn Giá</Price>
              <Quantity>Số Lượng</Quantity>
              <Money>Số Tiền</Money>
              <Action>Thao Tác</Action>
            </MiniNav>

            <DeleteItem
              itemName={itemName}
              productId={productId}
              deleteProduct={deleteAddressHandle}
              showDeleteItem={showDeleteItem}
              setShowDeleteItem={setShowDeleteItem}
            ></DeleteItem>
            
            {carts.map((item) => {
              totalPrice += item.quantity*item.price;
              return (
                <Item key={item.id}>
                  <ItemInfo>
                    <Checkbox
                      value={value}
                      checked={value}
                      onChange={({ target }) => setCheckbox(!value)}
                    />
                    <ItemImage src={item.img} ></ItemImage>
                    <ItemInfoDetails>
                      <ItemName>{item.itemName}</ItemName>
                      <ItemShipping src="https://cf.shopee.vn/file/4aa2f89064a3b9cd38170e3ded78c528"></ItemShipping>
                    </ItemInfoDetails>

                    <ItemType>
                      <ItemInfoType>Phân Loại Hàng:</ItemInfoType>
                      <ItemChosen>{item.chosen}</ItemChosen>
                    </ItemType>

                    <ItemPriceWrapper>
                      <ItemPrice>
                        {Number(item.price).toLocaleString("vi")}₫
                      </ItemPrice>
                    </ItemPriceWrapper>

                    <ItemQuantity>
                      <InputBtn onClick={() => handleDecrementBtn(item.id, item.quantity, item.itemName)}>
                        <Remove />
                      </InputBtn>
                      <Input defaultValue={item.quantity} type="button"></Input>
                      <InputBtn onClick={() => handleIncrement(item.id)}>
                        <Add />
                      </InputBtn>
                    </ItemQuantity>

                    <ItemMoney>
                      {Number(item.price * item.quantity).toLocaleString("vi")}₫
                    </ItemMoney>
                    <Handle>
                      <RemoveButton onClick={() => handleDeleteBtn(item.id)}>
                        Xóa
                      </RemoveButton>
                    </Handle>
                  </ItemInfo>
                </Item>
              );
            })}

            <TotalPrice>
              <Voucher>
                <VoucherImage src="https://cf.shopee.vn/file/84feaa363ce325071c0a66d3c9a88748"></VoucherImage>
                <VoucherTitle>Shopee Voucher</VoucherTitle>
                <VoucherSpace></VoucherSpace>
                <EnterVoucher>Chọn Hoặc Nhập Mã</EnterVoucher>
              </Voucher>
              <Line></Line>
              <Space>
                <Checkbox
                  value={false}
                  checked={false}
                  onChange={({ target }) => setCheckbox(value)}
                />
              </Space>
              <ShopeeCoin>
                <CoinImage src="https://cf.shopee.vn/file/a0ef4bd8e16e481b4253bd0eb563f784"></CoinImage>
                <CoinTitle>Shopee Xu</CoinTitle>
                <CoinAnnoun>Bạn chưa có Shopee Xu</CoinAnnoun>
                <CoinLogo src="https://cf.shopee.vn/file/a0ef4bd8e16e481b4253bd0eb563f784"></CoinLogo>
              </ShopeeCoin>
              <SalePrice>-₫0</SalePrice>
              <VoucherSpace></VoucherSpace>
              <Line></Line>
              <Total>
                <Checkbox
                  value={value}
                  checked={value}
                  onChange={({ target }) => setCheckbox(!value)}
                />
                <ChooseAll>Chọn Tất Cả ({carts.length})</ChooseAll>
                <ClearButton>Xóa</ClearButton>
                <SpaceSmall></SpaceSmall>
                <SaveButton>Lưu vào mục Đã thích</SaveButton>
                <VoucherSpace></VoucherSpace>

                <Payment>
                  <TotalPayment>
                    <TotalWrapper>
                      <TotalPricePayment>
                        <TotalMoneyTitle>
                          Tổng thanh toán ({carts.length} sản phẩm):
                        </TotalMoneyTitle>

                        <TotalMoney>{Number(totalPrice).toLocaleString("vi")}₫</TotalMoney>
                        <KeyboardArrowUp
                          style={{
                            cursor: "pointer",
                            color: "#8F8F8F",
                            margin: "0px 5px",
                          }}
                        ></KeyboardArrowUp>
                      </TotalPricePayment>
                      <SavePayment>
                        Tiết kiệm
                        <SaveMoney>₫300K</SaveMoney>
                      </SavePayment>
                    </TotalWrapper>
                  </TotalPayment>
                </Payment>

                <BuyNowButton>
                  <BuyNow>Mua hàng</BuyNow>
                </BuyNowButton>
              </Total>
            </TotalPrice>
            <RecommendWrapper>
              <RecommendProducts />
            </RecommendWrapper>
          </Wrapper>
        ) : (
          <React.Fragment>
            <NullCart>
              <NullCartLogo></NullCartLogo>
              <NullCartTitle>Giỏ hàng của bạn còn trống</NullCartTitle>
              <Link to="/searchhome">
                <NullCartLink>
                  <NullCartBuyNowButton>
                    <NullCartBuyNowSpan>MUA NGAY</NullCartBuyNowSpan>
                  </NullCartBuyNowButton>
                </NullCartLink>
              </Link>
            </NullCart>
            <RecommendWrapper>
              <RecommendProducts />
            </RecommendWrapper>
          </React.Fragment>
        )}
      </Container>
      <Footer />
    </React.Fragment>
  );
}

export default Cart;
