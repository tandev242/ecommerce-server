import React from "react";

export default function Category({ categoryList }) {
  return (
    <>
      <a className="home_category_list_grid" href={categoryList.link}>
        <div className="home_category_list_grid_item">
          <div className="home_category_list_grid_item_header">
            <div className="home_category_list_grid_item_header_frame">
              <div
                className="home_category_list_grid_item_header_img"
                style={{ backgroundImage: `url(${categoryList.imgUrl})` }}
              ></div>
            </div>
          </div>
          <div className="home_category_list_grid_item_titles">
            <div className="home_category_list_grid_item_title">
              {categoryList.title}
            </div>
          </div>
        </div>
      </a>
    </>
  );
}
