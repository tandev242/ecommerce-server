import React from "react";
import "./categoryList.css";

import { Swiper, SwiperSlide } from "swiper/react";

import "swiper/css";
import "swiper/css/grid";
import "swiper/css/navigation";

// import required modules
import { Grid, Navigation } from "swiper";
import Category from "./category";

export default function CategoryList() {
  const listCategory = [
    {
      id: 1,
      link: "https://shopee.vn/Th%E1%BB%9Di-Trang-Nam-cat.11035567",
      imgUrl: "https://cf.shopee.vn/file/687f3967b7c2fe6a134a2c11894eea4b_tn",
      title: "Thời Trang Nam"
    },
    {
      id: 2,
      link: "https://shopee.vn/Th%E1%BB%9Di-Trang-N%E1%BB%AF-cat.11035639",
      imgUrl: "https://cf.shopee.vn/file/75ea42f9eca124e9cb3cde744c060e4d_tn",
      title: "Thời Trang Nữ"
    },
    {
      id: 3,
      link:
        "https://shopee.vn/%C4%90i%E1%BB%87n-Tho%E1%BA%A1i-Ph%E1%BB%A5-Ki%E1%BB%87n-cat.11036030",
      imgUrl: "https://cf.shopee.vn/file/31234a27876fb89cd522d7e3db1ba5ca_tn",
      title: "Điện Thoại & Phụ Kiện"
    },
    {
      id: 4,
      link: "https://shopee.vn/M%E1%BA%B9-B%C3%A9-cat.11036194",
      imgUrl: "https://cf.shopee.vn/file/099edde1ab31df35bc255912bab54a5e_tn",
      title: "Mẹ & Bé"
    },
    {
      id: 5,
      link:
        "https://shopee.vn/Thi%E1%BA%BFt-B%E1%BB%8B-%C4%90i%E1%BB%87n-T%E1%BB%AD-cat.11036132",
      imgUrl: "https://cf.shopee.vn/file/978b9e4cb61c611aaaf58664fae133c5_tn",
      title: "Thiết Bị Điện Tử"
    },
    {
      id: 11,
      link:
        "https://shopee.vn/Nh%C3%A0-C%E1%BB%ADa-%C4%90%E1%BB%9Di-S%E1%BB%91ng-cat.11036670",
      imgUrl: "https://cf.shopee.vn/file/24b194a695ea59d384768b7b471d563f_tn",
      title: "Nhà Cửa & Đời Sống"
    },
    {
      id: 12,
      link: "https://shopee.vn/M%C3%A1y-T%C3%ADnh-Laptop-cat.11035954",
      imgUrl: "https://cf.shopee.vn/file/c3f3edfaa9f6dafc4825b77d8449999d_tn",
      title: "Máy Tính & Laptop"
    },
    {
      id: 13,
      link: "https://shopee.vn/S%E1%BA%AFc-%C4%90%E1%BA%B9p-cat.11036279",
      imgUrl: "https://cf.shopee.vn/file/ef1f336ecc6f97b790d5aae9916dcb72_tn",
      title: "Sắc Đẹp"
    },
    {
      id: 14,
      link:
        "https://shopee.vn/M%C3%A1y-%E1%BA%A2nh-M%C3%A1y-Quay-Phim-cat.11036101",
      imgUrl: "https://cf.shopee.vn/file/ec14dd4fc238e676e43be2a911414d4d_tn",
      title: "Máy Ảnh & Máy Quay Phim"
    },
    {
      id: 10,
      link: "https://shopee.vn/S%E1%BB%A9c-Kh%E1%BB%8Fe-cat.11036345",
      imgUrl: "https://cf.shopee.vn/file/49119e891a44fa135f5f6f5fd4cfc747_tn",
      title: "Sức Khỏe"
    },
    {
      id: 6,
      link: "https://shopee.vn/%C4%90%E1%BB%93ng-H%E1%BB%93-cat.11035788",
      imgUrl: "https://cf.shopee.vn/file/86c294aae72ca1db5f541790f7796260_tn",
      title: "Đồng Hồ"
    },
    {
      id: 15,
      link: "https://shopee.vn/Gi%C3%A0y-D%C3%A9p-N%E1%BB%AF-cat.11035825",
      imgUrl: "https://cf.shopee.vn/file/48630b7c76a7b62bc070c9e227097847_tn",
      title: "Giày Dép Nữ"
    },
    {
      id: 7,
      link: "https://shopee.vn/Gi%C3%A0y-D%C3%A9p-Nam-cat.11035801",
      imgUrl: "https://cf.shopee.vn/file/74ca517e1fa74dc4d974e5d03c3139de_tn",
      title: "Giày Dép Nam"
    },
    {
      id: 18,
      link: "https://shopee.vn/T%C3%BAi-V%C3%AD-N%E1%BB%AF-cat.11035761",
      imgUrl: "https://cf.shopee.vn/file/fa6ada2555e8e51f369718bbc92ccc52_tn",
      title: "Túi Ví Nữ"
    },
    {
      id: 8,
      link:
        "https://shopee.vn/Thi%E1%BA%BFt-B%E1%BB%8B-%C4%90i%E1%BB%87n-Gia-D%E1%BB%A5ng-cat.11036971",
      imgUrl: "https://cf.shopee.vn/file/7abfbfee3c4844652b4a8245e473d857_tn",
      title: "Thiết Bị Điện Gia Dụng"
    },
    {
      id: 22,
      link:
        "https://shopee.vn/Ph%E1%BB%A5-Ki%E1%BB%87n-Trang-S%E1%BB%A9c-N%E1%BB%AF-cat.11035853",
      imgUrl: "https://cf.shopee.vn/file/8e71245b9659ea72c1b4e737be5cf42e_tn",
      title: "Phụ Kiện & Trang Sức Nữ"
    },
    {
      id: 9,
      link: "https://shopee.vn/Th%E1%BB%83-Thao-Du-L%E1%BB%8Bch-cat.11035478",
      imgUrl: "https://cf.shopee.vn/file/6cb7e633f8b63757463b676bd19a50e4_tn",
      title: "Thể Thao & Du Lịch"
    },
    {
      id: 23,
      link: "https://shopee.vn/B%C3%A1ch-H%C3%B3a-Online-cat.11036525",
      imgUrl: "https://cf.shopee.vn/file/c432168ee788f903f1ea024487f2c889_tn",
      title: "Bách Hóa Online"
    },
    {
      id: 24,
      link:
        "https://shopee.vn/%C3%94-T%C3%B4-Xe-M%C3%A1y-Xe-%C4%90%E1%BA%A1p-cat.11036793",
      imgUrl: "https://cf.shopee.vn/file/3fb459e3449905545701b418e8220334_tn",
      title: "Ô Tô & Xe Máy & Xe Đạp"
    },
    {
      id: 25,
      link: "https://shopee.vn/Nh%C3%A0-S%C3%A1ch-Online-cat.11036863",
      imgUrl: "https://cf.shopee.vn/file/36013311815c55d303b0e6c62d6a8139_tn",
      title: "Nhà Sách Online"
    },
    {
      id: 27,
      link: "https://shopee.vn/Balo-T%C3%BAi-V%C3%AD-Nam-cat.11035741",
      imgUrl: "https://cf.shopee.vn/file/18fd9d878ad946db2f1bf4e33760c86f_tn",
      title: "Balo & Túi Ví Nam"
    },
    {
      id: 28,
      link: "https://shopee.vn/Th%E1%BB%9Di-Trang-Tr%E1%BA%BB-Em-cat.11036382",
      imgUrl: "https://cf.shopee.vn/file/4540f87aa3cbe99db739f9e8dd2cdaf0_tn",
      title: "Thời Trang Trẻ Em"
    },
    {
      id: 29,
      link: "https://shopee.vn/%C4%90%E1%BB%93-Ch%C6%A1i-cat.11036932",
      imgUrl: "https://cf.shopee.vn/file/ce8f8abc726cafff671d0e5311caa684_tn",
      title: "Đồ Chơi"
    },
    {
      id: 30,
      link:
        "https://shopee.vn/Gi%E1%BA%B7t-Gi%C5%A9-Ch%C4%83m-S%C3%B3c-Nh%C3%A0-C%E1%BB%ADa-cat.11036624",
      imgUrl: "https://cf.shopee.vn/file/cd8e0d2e6c14c4904058ae20821d0763_tn",
      title: "Giặt Giũ & Chăm Sóc Nhà Cửa"
    },
    {
      id: 31,
      link:
        "https://shopee.vn/Ch%C4%83m-S%C3%B3c-Th%C3%BA-C%C6%B0ng-cat.11036478",
      imgUrl: "https://cf.shopee.vn/file/cdf21b1bf4bfff257efe29054ecea1ec_tn",
      title: "Chăm Sóc Thú Cưng"
    },
    {
      id: 32,
      link: "https://shopee.vn/Voucher-D%E1%BB%8Bch-V%E1%BB%A5-cat.11035898",
      imgUrl: "https://cf.shopee.vn/file/b0f78c3136d2d78d49af71dd1c3f38c1_tn",
      title: "Voucher & Dịch Vụ"
    }
  ];

  return (
    <div className="section_category_list">
      <div className="home_category_list">
        <div className="category_title">
          <div className="title">DANH MỤC</div>
        </div>
        <Swiper
          slidesPerView={10}
          grid={{
            rows: 2
          }}
          spaceBetween={0}
          navigation={{
            clickable: true
          }}
          modules={[Grid, Navigation]}
          className="mySwiper slider-thuonghieu2"
        >
          {listCategory.map((num) => (
            <SwiperSlide key={num.id}>
              <Category categoryList={num} />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
}
