import React from 'react';

export default function Arrows({ prevSlide, nextSlide }) {
    return (
        <>
            <div className="arrows arrow_prev">
                <span className="prev" onClick={prevSlide}>
                    &#10094;
                </span>
            </div>
            <div className='arrows arrow_next'>
                <span className="next" onClick={nextSlide}>
                    &#10095;
                </span>
            </div>
        </>

    )
}
