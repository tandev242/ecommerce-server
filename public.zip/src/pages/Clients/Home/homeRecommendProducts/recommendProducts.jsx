import React, { useState, useEffect } from "react";
import Product from "./product";
import { Link } from "react-router-dom";
import { collection, getDocs, query, orderBy } from "firebase/firestore";
import { db } from "../../../../firebase/firebase-config";

import "./recommendProduct.css";

export default function RecommendProducts() {

  const [productList, setProductList] = useState([]);

  useEffect(() => {
    const colRef = collection(db, "productList");
    const q = query(colRef, orderBy("id_product", "asc"));
    getDocs(q).then((snapshot) => {
      let productList = [];
      snapshot.docs
        .forEach((doc) => {
          productList.push({
            id: doc.id,
            ...doc.data(),
          });
          setProductList(productList);
        })
    });
  }, []);
  
  return (
    <div className="section_recommend_products_wrapper">
      <nav className="recommend_products_wrapper" style={{ top: "7.375rem" }}>
        <ul className="tabs_header">
          <li className="tabs_header_tab">
            <div className="tabs_header_tab_title">
              <span style={{ color: "rgb(238, 77, 45)" }}>GỢI Ý HÔM NAY</span>
            </div>
          </li>
        </ul>
      </nav>

      <div className="recommend_products_panels">
        <section className="recommend_products_panels__panel">
          <div className="panel">
            <Product listProducts={productList} />

            <div className="recommend_products_show_more">
              <Link
                className="recommend_products_btn_show_more"
                to="/page_products/*"
              >
                Xem thêm
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
