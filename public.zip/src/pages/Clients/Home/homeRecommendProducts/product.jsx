import React from "react";
import "./product.css";
import { Link } from "react-router-dom";

export default function Product({ listProducts }) {
  return (
    <>
      {listProducts.map((product) => (
        <div className="product" key={product.id_product}>
          <Link
            className="list_product_a_hover"
            style={{ textDecoration: "none", backgroundColor: "transparent" }}
            to={`/detail/${product.id_product}`}
          >
            <div className="recommend_product_padding_bottom">
              <div className="recommend_product_border">
                  <div style={{ pointerEvents: "none" }}>
                    <div className="recommend_product_frame">
                      <img
                        alt={product.title}
                        src={product.img[0]}
                        className="recommend_product_img"
                        style={{ objectFit: "contain" }}
                      ></img>
                      <div className="recommend_product_discount">
                        <div className="recommend_product_discount_title">
                          <span>{product.saleOff}%</span>
                          <span style={{ color: "#fff" }}>GIẢM</span>
                        </div>
                      </div>
                    </div>
                  </div>

                <div className="recommend_product_card_header">
                  <div className="recommend_product_header">
                    <div className="recommend_product_header_title">
                      <div className="recommend_product_header__title">
                        {product.title}
                      </div>
                    </div>
                  </div>

                  <div className="recommend_product_price">
                    <div className="recommend_product_price_left">
                      <span style={{ fontSize: ".75rem", color: "#ee4d2d" }}>
                        ₫
                      </span>
                      <span className="recommend_product_price_left__price">
                        {product.price}.000
                      </span>
                    </div>
                  </div>
                </div>

                <div className="recommend_product_hover_footer">
                  Tìm sản phẩm tương tự
                </div>
              </div>
            </div>
          </Link>
        </div>
      ))}
    </>
  );
}
