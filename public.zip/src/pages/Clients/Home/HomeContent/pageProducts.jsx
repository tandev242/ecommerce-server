import React, { useState, useEffect } from "react";
import Product from "../homeRecommendProducts/product";
import "./pageProducts.css";
import Header from "../../../../components/header";
import Footer from "../../../../components/footer";
import { collection, getDocs, orderBy, limit, query, startAfter } from "firebase/firestore";
import { db } from "../../../../firebase/firebase-config";


export default function PageProducts() {

  const itemsPerPage = 8;
  const [list, setList] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [idOfLastProduct, setIdOfLastProduct] = useState(0);
  const [idOfFirstProduct, setIdOfFirstProduct] = useState(0);
  const [productList, setProductList] = useState([]);
  const [arrOfCurrButtons, setArrOfCurrButtons] = useState([]);
  const [pages, setPages] = useState([]);

  useEffect(() => {
    const tempPages = [];
    for (let i = 1; i <= Math.ceil(productList.length / itemsPerPage); i++) {
      tempPages.push(i);
    }
    setPages(tempPages);
  }, [productList,itemsPerPage]);

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [currentPage]);

  useEffect(() => {
    const colRef = collection(db, "productList");
    const q = query(colRef, orderBy("id_product", "asc"));
    getDocs(q).then((snapshot) => {
      let productList = [];
      snapshot.docs
        .forEach((doc) => {
          productList.push({
            id: doc.id,
            ...doc.data(),
          });
          setProductList(productList);
        })

    });
  }, []);

  useEffect(() => {
    setIdOfLastProduct(currentPage * itemsPerPage);
    setIdOfFirstProduct(idOfLastProduct - itemsPerPage);
    const colRef = collection(db, "productList");
    const q = query(colRef, orderBy("id_product", "asc"), startAfter(idOfFirstProduct), limit(itemsPerPage));
    let testList = [];
    const fetchData = async () => {
      await getDocs(q).then((snapshot) => {
        snapshot.docs
          .forEach((doc) => {
            testList.push({
              id: doc.id,
              ...doc.data(),
            });
            setList(testList);
          })

      });
    }
    fetchData();
  }, [currentPage, idOfFirstProduct, idOfLastProduct]);

  useEffect(() => {
    let tempNumberOfPages = [...arrOfCurrButtons]

    let dotsInitial = '...'
    let dotsLeft = '... '
    let dotsRight = ' ...'

    if (pages.length < 6) {
      tempNumberOfPages = pages
    }

    else if (currentPage >= 1 && currentPage <= 3) {
      tempNumberOfPages = [1, 2, 3, 4, 5, dotsInitial]
    }

    else if (currentPage >= 4 && currentPage <= 5) {
      const sliced = pages.slice(0, 7)
      tempNumberOfPages = [...sliced, dotsInitial]
    }

    else if (currentPage === 6) {
      tempNumberOfPages = ([1, 2, dotsLeft, 4, 5, 6, 7, 8, dotsRight])
    }

    else if (currentPage === 7) {
      tempNumberOfPages = ([1, 2, dotsLeft, 5, 6, 7, 8, 9]);
    }

    setArrOfCurrButtons(tempNumberOfPages)

  }, [currentPage, arrOfCurrButtons, pages]);

  const handleClick = (event) => {
    setCurrentPage(Number(event.target.id));
  };

  const showNext = () => {
    if (currentPage < 9 && currentPage < pages.length) {
      setCurrentPage(currentPage + 1);
    }
  };

  const showPrevious = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <>
      <Header />
      <div className="home_page">
        <div className="page_products_main">
          <div className="page_products_header">
            <h1 className="page_products_title">Tất cả</h1>
            <hr className="page_products_line"></hr>
          </div>

          <div className="page_products_list_product">
            <Product listProducts={list} />
          </div>

          <div className="page_controller">
            <button className="page_controller_btn btn_prev" onClick={() => showPrevious()}>&#10094;</button>

            {
              arrOfCurrButtons.map((number) => (
                <button
                  onClick={handleClick}
                  id={number}
                  key={number}
                  className={currentPage === number ? 'page_controller_btn_active' : 'page_controller_btn_no_outline'}
                >{number}</button>
              ))
            }

            <button className="page_controller_btn btn_next" onClick={() => showNext()}>&#10095;</button>
          </div>
        </div>

      </div>
      <Footer />
    </>
  );
}
