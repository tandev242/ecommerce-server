import React, { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Alert } from "@mui/material";
import { addDoc, collection } from "firebase/firestore";
import { auth, db } from "../../../firebase/firebase-config";
import Footer from "../../../components/footer";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { useDispatch } from "react-redux";
import { signup } from "../../../slices/authSlice";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const profilePic =
    "https://scontent.xx.fbcdn.net/v/t1.15752-9/260973034_620697476041810_7358295328192465228_n.jpg?stp=dst-jpg_p206x206&_nc_cat=103&ccb=1-7&_nc_sid=aee45a&_nc_ohc=Gq1GzLV0CYgAX9XLFBD&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_AVJyltMWzSreRu7oIMcMcbLg-knSJRRvF3--F0Hzpg07oA&oe=63052D3E";
  const [err, setErr] = useState("");
  const [errIcon, setErrIcon] = useState("");
  const [loadingg, setLoadingg] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSignUp = async (e) => {
    e.preventDefault();
    if(email && password && name) {
      const res = await dispatch(signup({ email, password, name})).unwrap()
      if(res.status === 201) {
        alert("Đăng nhập thành công !")
        navigate('/signin')
      }
    }
  };
  return (
    <>
      <nav className="navbar__sign">
        <div className="navbar__sign__content">
          <div className="navbar__sign__content--left">
            <Link to="/">
              <a href="/" className="navbar__sign_content--logo">
                <img
                  className="navbar__sign_content--logo--img"
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Shopee.svg/2560px-Shopee.svg.png"
                  alt="logo"
                />
              </a>
            </Link>
            <div className="navbar__sign__content--left--title">Đăng ký</div>
          </div>
          <Link to="/support">
            <a className="SignLink" href="support" target={"_blank"}>
              Bạn cần giúp đỡ?
            </a>
          </Link>
        </div>
      </nav>

      <div className="sign__container">
        <div className="sign__container__content">
          <section className="SectionSign">
            <h1 className="H1__tag">Đăng Ký</h1>
            {/* {currentUser.email} */}
            <form className="FormSign" onSubmit={handleSignUp}>
              <label className="LabelSign">Tên Người Dùng</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nhập tên của bạn"
                required
              />

              <label className="LabelSign">Địa Chỉ Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Nhập địa chỉ email"
                required
              />

              <label className="LabelSign">Mật Khẩu</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Nhập mật khẩu"
                required
              />

              <label className="LabelSign">Xác Nhận Mật Khẩu</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Xác nhận mật khẩu"
                required
              />

              <button disabled={loadingg} className="ButtonSign" type="submit">
                Đăng Ký
              </button>
              {err && (
                <Alert
                  variant="standard"
                  severity={errIcon}
                  style={{ margin: "15px 54px 0 0" }}
                >
                  {err}
                </Alert>
              )}
            </form>
            <div className="BottomSign">
              <p>
                Bạn đã đăng ký?
                <br />
                <span className="line">
                  <Link to="/signin">
                    <a className="SignLink" href="signin" target={"_blank"}>
                      Đăng Nhập
                    </a>
                  </Link>
                </span>
              </p>
            </div>
          </section>
        </div>
      </div>
      <Footer />
    </>
  );
}
