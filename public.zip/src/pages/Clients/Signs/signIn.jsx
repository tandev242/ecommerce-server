import React, { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Alert } from "@mui/material";

import {
  auth,
  signInWithEmailAndPassword,
} from "../../../firebase/firebase-config";
import { useDispatch } from "react-redux";
import { signin } from "../../../slices/authSlice";
import Footer from "../../../components/footer";

export default function Signin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLogin = async (e) => {
    e.preventDefault();

    if(email && password) {
      const res = await dispatch(signin({ email, password})).unwrap()
      if(res.status === 200) {
        alert("Đăng nhập thành công !")
        navigate('/')
      }
    }
  };

  return (
    <>
      <nav className="navbar__sign">
        <div className="navbar__sign__content">
          <div className="navbar__sign__content--left">
            <Link to="/">
              <a href="/" className="navbar__sign_content--logo">
                <img
                  className="navbar__sign_content--logo--img"
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Shopee.svg/2560px-Shopee.svg.png"
                  alt="logo"
                />
              </a>
            </Link>
            <div className="navbar__sign__content--left--title">Đăng nhập</div>
          </div>
          <Link to="/support">
            <a className="SignLink" href="support" target={"_blank"}>
              Bạn cần giúp đỡ?
            </a>
          </Link>
        </div>
      </nav>

      <div className="sign__container">
        <div className="sign__container__content">
          <section className="SectionSign">
            <h1 className="H1__tag">Đăng Nhập</h1>
            {/* {currentUser.email} */}
            {/* {error && <Alert variant="danger">{error}</Alert>} */}
            <form className="FormSign" onSubmit={handleLogin}>
              <label className="LabelSign">Địa Chỉ Email</label>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                type="email"
              />

              <label className="LabelSign">Mật Khẩu</label>
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                type="password"
              />

              <button className="ButtonSign" type="submit">
                Đăng Nhập
              </button>
            </form>

            <div className="BottomSign">
              <p>
                Chưa có tài khoản?
                <br />
                <span className="line">
                  <Link to="/signup">
                    <a className="SignLink" href="signup" target={"_blank"}>
                      Đăng Ký
                    </a>
                  </Link>
                </span>
              </p>
            </div>
          </section>
        </div>
      </div>
      <Footer />
    </>
  );
}
