
import Header from "../../../components/header";
import Footer from "../../../components/footer";
import styled from 'styled-components';
import React, { useState, useEffect } from 'react';
import "./main.css"
import SearchPrice from "./SearchPrice"
import { useSearchParams } from "react-router-dom";

import Dbjson from "./db.json"
import ReactPaginate from "react-paginate";
import Button from "./button";


//========== Xử lý chỗ download =============


const Navigator = styled.nav`
     padding-left: 4px;
    padding-right: 4px;
    -webkit-flex: 0 0 16.66667%;
    -ms-flex: 0 0 16.66667%;
    flex: 0 0 16.66667%;
    max-width: 16.66667%;
    display: block;

`
const H3 = styled.h3`
    color: #333;
    text-transform: uppercase;
    font-weight: 600;
    font-size: 1rem;
    line-height: 1.8rem;
    margin: 8px 0;
`
const DIV1 = styled.div`
    border-bottom: 1px solid #ccc;
    padding: 20px 0;
`
const DIV2 = styled.div`
    color: #333;
    font-size: 0.95rem;
    padding: 0 0 10px;
`


const UL1 = styled.ul`
    list-style: none;
    margin: 0;
    padding: 0;
`
const LI1 = styled.li`
    display: flex;
    align-items: center;
    font-size: 0.85rem;
    color: #333;
    padding: 4px 0;
`


const BUTTON2 = styled.button`
    width: 100%;
    color: white;
    background-color: #fb5533;
    min-width: 142px;
    height: 34px;
    text-decoration: none;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 12px;
    border-radius: 2px;
    font-size: 0.85rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin: 20px 0;
`
const I = styled.i`
    font-size: 1rem;
    margin-right: 4px;
`
const SpanFillter = styled.i`
   overflow: hidden;
    display: -webkit-box;
    text-overflow: ellipsis;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
    line-height: 1rem;
    max-height: 3rem;
    cursor: pointer;
    font-size: 0.85rem;
    word-wrap: break-word;
    padding: 8px 0;
`
const Contariner = styled.div`
    background-color: var(--contain-color);
    padding-top: 24px;
`
const Grid = styled.div`
    max-width: 1200px;
    margin: 0 auto;
    width: 100%;
    display: block;
    padding: 0;
`
const Gutter = styled.div`
    display: flex;
    flex-wrap: wrap;
    margin-left: -5px;
    margin-right: -5px;
`
const PopularProduct  = styled.div`
    padding-left: 5px;
    padding-right: 5px;
    flex: 0 0 83.33333%;
    max-width: 83.33333%;
    display: block;

`
const SmGutter = styled.div`
    margin-left: -5px;
    margin-right: -5px;
    display: flex;
    flex-wrap: wrap;
`

const ItemLink = styled.a`
    position: relative;
    margin: 5px 0;
    text-decoration: none;
    display: block;
    background-color: var(--white-color);
    box-shadow: 0 2px 5px rgb(0 0 0 / 20%);
    transition: transform linear 0.1s;
    &:hover{
        transform: translateY(-2px);
        border: 1px solid var(--primary-color);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        z-index: 2;
    }
`
const ItemImg = styled.div`
    padding-top: 100%;
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
  
`
const ItemInfo = styled.div`
    padding: 10px;
  
`
const ItemName = styled.h4`
    font-size: 0.85rem;
    font-weight: 400;
    color: var(--text-color);
    line-height: 1.4rem;
    margin: 0 0 20px;
    height: 2.8rem;
    overflow: hidden;
    display: block;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  
`
const ItemPrice = styled.div`
    display: flex;
    align-items: baseline;
    justify-content: space-between;
`
const PriceOld = styled.p`
    margin: 0;
    font-size: 0.85rem;
    color: #999;
    text-decoration: line-through;
`
const PriceNew = styled.p`
      margin: 0;
    font-size: 0.85rem;
    color: var(--primary-color);
    margin-right: auto;
    margin-left: 5px;
`
const PriceIcon = styled.i`
    font-size: 0.85rem;
    color: lightseagreen;
`
const ItemFooter = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 5px;
`
const ItemSave = styled.div`
    
 `
const Input = styled.input`
     display: none;
     
    
 `
const Label = styled.label`
    
     font-size: 0.85rem;
     color: #999;
     cursor: pointer;
 `
 const ItemStar = styled.div`    
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 0.7rem;
    margin-left: auto;
    margin-right: 5px;
`
const StarCheck = styled.i`    
    color: #ffe400;
    font-weight: 900;
`
const StarUncheck = styled.i`    
    color: #ffe400;
    font-weight: unset;
`
const ItemSaled = styled.div`    
    color: #333;
    font-size: 0.85rem;
`
const ItemOrigin = styled.div`    
    text-align: right;
    font-size: 0.85rem;
    color: var(--text-color);
    margin: 5px 0;
`
const ItemFavourite = styled.div`    
    position: absolute;
    top: 10px;
    left: -4px;
    color: var(--white-color);
    background-color: var(--primary-color);
    font-size: 0.85rem;
    padding: 0 4px;
    border-bottom-right-radius: 3px;
    border-top-right-radius: 3px;
`
const ItemSaleoff = styled.div`    
    position: absolute;
    right: 0;
    top: 0;
    z-index: 1;
    &::after{
        content: "";
    width: 0;
    height: 0;
    left: 0;
    bottom: -4px;
    position: absolute;
    border-color: transparent rgba(255,212,36,.9);
    border-style: solid;
    border-width: 0 18px 4px;
    }
`
const SaleLayout = styled.div`    
       display: flex;
    flex-direction: column;
    text-align: center;
    position: relative;
    box-sizing: border-box;
    font-weight: 400;
    line-height: .8125rem;
    color: #ee4d2d;
    text-transform: uppercase;
    width: 36px;
    padding: 4px 2px 3px;
    background-color: rgba(255,212,36,.9);

    font-size: .75rem;
`
const ItemSaleoffvalue = styled.span`    
       display: flex;
    flex-direction: column;
    text-align: center;
    position: relative;
    font-weight: 400;
    line-height: .8125rem;
    color: #ee4d2d;
    text-transform: uppercase;
    font-size: .75rem;
    display: inline-block;
    box-sizing: border-box;
    position: relative;
    padding: 4px 2px 3px;
   
    background-color: rgba(255,212,36,.9);
`
const ItemSaleofflabel = styled.div`    
        color: white;
    font-size: 0.75rem;
    font-weight: 500;
`
const Add = styled.div`    
    display: flex;
    align-items: center;
    font-size: 0.95rem;
    color: #333;
    cursor: pointer;
    padding: 4px 0;
    color: #887878;
`
const IconDown = styled.i`    
    font-size: 11px;
    align-items: center;
    display: flex;
    justify-content: center;
    margin-left: 6px;
    margin-top: 4px;
`
const allCategories = ['Phổ Biến','Mới Nhất','Bán Chạy','Tăng Dần','Giảm Dần'];


// console.log(allCategories);
const Home = () => {
 const [menuItem, setMenuItem] = useState(Dbjson);
 const [check, setCheck] = useState(0);
 const [buttons] = useState(allCategories);

 const [searchParams] = useSearchParams();
 const [showJob, setShow] = useState(false);

 const [pageNumber, setPageNumber] = useState(0);
 const min_price = searchParams.get('min_price') === null ? '' : searchParams.get('min_price');
 const max_price = searchParams.get('max_price') === null ? '' : searchParams.get('max_price');
 const search = searchParams.get('search') === null ? '' : searchParams.get('search');

  const usersPerPage = 25;
  const pagesVisited = pageNumber * usersPerPage;
  useEffect(() => {
    filterProducts();
}, []);
const filterProducts = () => {
    // check minimum one entry occur
    if (search.length || min_price.length || max_price.length) {

        const min = parseFloat(min_price);
        const max = parseFloat(max_price);

        // filter products with these conditions
        const filtered = menuItem.filter(product => {
            // if min price > product price get product
            if (min > 0 && min > product.newPrice) {
                return false;
            }

            // max price max price < product price get product
            if (max > 0 && max < product.newPrice) {
                return false;
            }

            // search
            if (search.length > 0 && ! product.name.toLowerCase().includes(search.toLowerCase())) {
                return false;
            }

            return true;
        })

        // set products
        setMenuItem(filtered);
    }
}
  const filterResult = (catItem) => {
    const result = Dbjson.filter((curDate) => {
        return curDate.category === catItem;
    });
    setMenuItem(result);
}
const Addresses = (catItem) => {
    const result = Dbjson.filter((curDate) => {
        return curDate.origin === catItem;
    });
    setMenuItem(result);
}
const Shipping = (catItem) => {
    const result = Dbjson.filter((curDate) => {
        return curDate.id > catItem;
    });
    setMenuItem(result);
}



  
  const filter = (button) =>{

    // if(button === 'Tất Cả'){
    //   setMenuItem(Dbjson);
    //   return;
    // }
   
    if(button === 'Phổ Biến'){
        const filteredData = Dbjson.sort((a, b) => a.id > b.id ? 1:-1 );
         
        setMenuItem(filteredData);
        setCheck(0);
         return;
    }
      if(button === 'Mới Nhất'){
        const filteredData = Dbjson.sort((a, b) => a.id < b.id ? 1:-1 );
      setMenuItem(filteredData)
      setCheck(1)
      }
        if(button === 'Bán Chạy'){
            const filteredData = Dbjson.sort((a, b) => a.saleOff < b.saleOff ? 1:-1 );
        setMenuItem(filteredData)
         setCheck(2)
    }        
     if(button === 'Tăng Dần'){
         const filteredData = Dbjson.sort((a, b) => a.newPrice > b.newPrice ? 1:-1 );
         
         setMenuItem(filteredData);
         setCheck(3)
         
         }
     if(button === 'Giảm Dần'){
         const filteredData = Dbjson.sort((a, b) => a.newPrice < b.newPrice ? 1:-1);
         setMenuItem(filteredData);
         setCheck(4)
      
    }
  }
  const displayUsers = menuItem
   
   
    .slice(pagesVisited, pagesVisited + usersPerPage)
   
    .map((post) => {
      
      return (
       
        <div key = {post.id} className="col l-2-4 m-3 c-6 home-product-item">
           <ItemLink >
             <ItemImg style={{backgroundImage: `url(./img/home/${post.id}.PNG)`}} ></ItemImg>
               <ItemInfo>
                <ItemName>{post.name}</ItemName>
                <ItemPrice>
                    <PriceOld >{post.oldPrice}đ</PriceOld>
                    <PriceNew >{post.newPrice}.000đ</PriceNew>
                    <PriceIcon className="fas fa-shipping-fast"></PriceIcon>
                </ItemPrice>
                <ItemFooter>
                    <ItemSave>
                        <Input type="checkbox" id={post.id} />
                        <Label htmlFor={post.id} className="far fa-heart"></Label>
                    </ItemSave>
                    <ItemStar>
                        <StarCheck className="far fa-star"></StarCheck>
                        <StarCheck className="far fa-star"></StarCheck>
                        <StarCheck className="far fa-star"></StarCheck>
                        <StarCheck className="far fa-star"></StarCheck>
                        <StarUncheck className="far fa-star"></StarUncheck>
                    </ItemStar>
                    <ItemSaled>Đã bán {post.saled}k</ItemSaled>
                </ItemFooter>
                <ItemOrigin>{post.origin}</ItemOrigin>
                <ItemFavourite>
                    Yêu thích
                </ItemFavourite>
                <ItemSaleoff> 
                    <SaleLayout>
                    <ItemSaleoffvalue>{post.saleOff}%</ItemSaleoffvalue>
                    <ItemSaleofflabel>GIẢM</ItemSaleofflabel>
                    </SaleLayout>
                </ItemSaleoff>
            </ItemInfo>
            <div className="home-product-item-footer">Tìm sản phẩm tương tự</div>
            
        </ItemLink>
     </div>

        )
       
    });

  const pageCount = Math.ceil(menuItem.length / usersPerPage);

  const changePage = ({ selected }) => {
    setPageNumber(selected);
  };

  return (
    <React.Fragment>
        <Header/>
      <Contariner>
            <Grid>
                <Gutter>
                <Navigator>
            <H3>
                
            <I className="fas fa-list-ul"/>BỘ LỌC TÌM KIẾM
             </H3>  
             <DIV1>

            <DIV2>Theo Danh Mục</DIV2>
            <UL1>
                <LI1>
                    <SpanFillter onClick={() => filterResult('Loa')} >Loa</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => filterResult('Sạc và dây cáp')} >Các loại sạc và dây cáp</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => filterResult('USB')} >USB</SpanFillter> 
                </LI1> 
                 {showJob === false ? <Add onClick={() => setShow(prev => !prev)}>Thêm<IconDown className="fas fa-angle-down"/></Add>
                    :
                 <>
                <LI1>
                <SpanFillter onClick={() => filterResult('Tai nghe và bàn phím')} >Tai nghe và bàn phím</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => filterResult('Wifi')} >Wifi</SpanFillter>
                </LI1> 
                </>
                }
            </UL1>
        </DIV1> 
            <DIV1>
            <DIV2>Nơi Bán</DIV2>
            <UL1>
                <LI1>
                <SpanFillter onClick={() => Addresses('Lâm Đồng')} >Lâm Đồng</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => Addresses('Hà Nội')} >Hà Nội</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => Addresses('Hồ Chí Minh')} >Hồ Chí Minh</SpanFillter>
                </LI1> 
              
            </UL1>
            
            </DIV1>
        <DIV1>
            <DIV2>Đơn Vị Vận Chuyển</DIV2>
            <UL1>
                <LI1>
                <SpanFillter onClick={() => Shipping(1)} >Hỏa tốc</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => Shipping(50)} >Nhanh</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => Shipping(100)} >Tiết Kiệm</SpanFillter>
                </LI1> 
            </UL1>
        </DIV1> 
        <DIV1>
            <DIV2>Thương Hiệu</DIV2>
            <UL1>
                <LI1>
                <SpanFillter onClick={() => Shipping(25)} >KingSton</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => Shipping(76)} >Sandisk</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => Shipping(96)} >Seagate</SpanFillter>
                </LI1> 
            </UL1>
        </DIV1>
     
        <SearchPrice/>
        <DIV1>
            <DIV2>Tình Trạng</DIV2>
            <UL1>
                <LI1>
                <SpanFillter onClick={() => Shipping(50)} >Mới</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => Shipping(140)} >Đã sử dụng</SpanFillter>
                </LI1>      
            </UL1>
        </DIV1> 
        <DIV1>
            <DIV2>Lựa Chọn Thanh Toán</DIV2>
            <UL1>
                <LI1>
                <SpanFillter onClick={() => Shipping(50)} >Thanh Toán Khi Nhận Hàng</SpanFillter>
                </LI1>
                <LI1>
                <SpanFillter onClick={() => Shipping(85)} >Chuyển Khoản</SpanFillter>
                </LI1>
                <LI1>
                <SpanFillter onClick={() => Shipping(120)} >Trả Góp</SpanFillter>
                </LI1>
            </UL1>
        </DIV1> 
 
        <DIV1>
            <DIV2>Dịch Vụ & Khuyến Mãi</DIV2>
            <UL1>
                <LI1>
                <SpanFillter onClick={() => Shipping(25)} >FreeShip XTra</SpanFillter>
                </LI1>
                <LI1>
                <SpanFillter onClick={() => Shipping(75)} >Hoàn Xu XTra</SpanFillter>
                </LI1>
                <LI1>
                <SpanFillter onClick={() => Shipping(99)} >Đang Giảm Giá</SpanFillter>
                </LI1> 
                <LI1>
                <SpanFillter onClick={() => Shipping(119)} >Miễn Phí Vận Chuyển</SpanFillter>
                </LI1>
            </UL1> 
            
        </DIV1> 
      
        <BUTTON2>XÓA TẤT CẢ</BUTTON2>
        </Navigator>
                    
                    <PopularProduct>
                         <Button button={buttons} filter={filter} check={check}/>
                        <SmGutter>
                             {displayUsers}
                        </SmGutter>
                        <ReactPaginate
                        previousLabel={<i className="fa fa-angle-left"></i>}
                        nextLabel={<i className="fa fa-angle-right"></i>}
                        pageCount={pageCount}
                        onPageChange={changePage}
                        containerClassName={"paginationBttns"}
                        previousLinkClassName={"previousBttn"}
                        nextLinkClassName={"nextBttn"}
                        disabledClassName={"paginationDisabled"}
                        activeClassName={"paginationActive"}
                         />
                        
                    </PopularProduct>
                </Gutter>
            </Grid>
      </Contariner>
   <Footer/>
    </React.Fragment>
  );
}

export default Home;
