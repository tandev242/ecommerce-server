import React from "react";
import { ThemeProvider } from "styled-components";
import { GlobalStyles } from "../../../styles/global";
import { Theme } from "../../../styles/theme";
import UserMain from "./userRoutes";
import Header from "../../../components/header";
import Footer from "../../../components/footer";

const User = () => {
  return (
    <div style={{display: "flex", flexDirection: "column", paddingnBottom: "30px"}}>
      <Header />
      <div style={{paddingBottom: "70px"}}>
        <ThemeProvider theme={Theme}>
          <GlobalStyles />
          <UserMain />
        </ThemeProvider>
      </div>
      <Footer/>
    </div>
  )
}

export default User;
