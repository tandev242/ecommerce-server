import React, {useState, useEffect} from "react";
import styled from "styled-components";
import { BiSearch } from "react-icons/bi"
    import ButtonPurchase from "./button";

const Container = styled.div`
    position: relative;
    margin-top: 20px;
    left: 0;
    top: 0;
    width: 970px;
    
    display: flex;
    flex-direction: column;
    border-radius: 1px;
`
const CenterHandle = styled.div`
  background-color: #fff;
  height: 470px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  font-size: 20px;
  margin-top: 12px;

  img{
    margin-bottom: 15px;
    width: 100px;
    height: 100px;
  }
`
const Search = styled.div`
    padding: 12px 0;
    margin: 12px 0;
    display: flex;
    align-items: center;
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.05);
    color: #212121;
    background: #eaeaea;
    width: 100%;
    border-radius: 2px;
    
    .input {
        flex: 1;
        font-size: 14px;
        line-height: 16px;
        border: 0;
        outline: none;
        background-color: #efe9e9c1;
    }
`

const Wrapper = styled.section`

`
const Content = styled.div`
    background-color: #ffffff;
    margin-bottom: 12px;
    border-radius: 2px;
`

const HeaderContent = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid rgba(0,0,0,.09);;
    .storeName {
        width: 100px;
        font-size: 16px;
        font-weight: 550;
    }
    .status{
        text-transform: uppercase;
        color: #EE4D2D;
        font-weight: 550;
    }
    .date {
        display: flex;
        flex-direction: column;

        label {
            color : #0000008A;
            display: inline-block;
            width: 110px;
        }
    }
`

const MainContent = styled.div`
    display: flex;
    flex-direction: column;
    .item{
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid rgba(0,0,0,.09);;
        padding: 10px 15px;
    }
    .wrapLeft{
        width: 800px;
        display: flex;
        align-items: center;
    }
    .img {
        float: left;
        width: 90px;
        height: 90px;
        border: 1px solid rgba(0,0,0,.09);
    }
    .wrapLeftChil{
        display: flex;
        flex-direction: column;
    }
    .classify{
        color: #0000008A;
    }
    span {
        padding: 5px 10px;
    }
    .wrapRight{
        width: 100px;
    }
    .price{
        color: #EE4D2D;
        font-size: 16px;
    }
    
`
const FooterContent = styled.div`
    display: flex;
    flex-direction: column;
    text-align: right;
    background-color: #fffefb;
    height: 120px;
    padding: 20px 40px;

    .wrap{
        padding-bottom: 15px;
    }

    .fullPrice{
        color: #EE4D2D;
        font-size: 22px;
    }

`

const ButtonPrimary = styled.button`
  height: 40px;
  width: 160px;
  font-size: 16px;
  background-color: ${({theme}) => theme.mainColor};
  cursor: pointer;
  border: none;
  border-radius: 2px;
  color: ${({theme}) => theme.textColorWhite};

  :hover {
    background-color: ${({theme}) => theme.btnPrimaryColorHover};
  }
`

const ListButton = ['Tất cả', 'Chờ xác nhận', 'Chờ lấy hàng', 'Đang giao', 'Đã giao', 'Đã hủy'];
function UserPurchase() {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [purchases, setPurchases] = useState([]);
    const [buttons] = useState(ListButton);
    const [check, setCheck] = useState(0);
      useEffect(()=> { 
        fetch("../../purchase.json")
        .then(res => res.json())
        .then(
          (result) => {
            setIsLoaded(true);
            setPurchases(result.filter(item => (check === 0) ? (item.type !== check) : (item.type === check)));
          },
          (error) => {
            setIsLoaded(true);
            setError(error);
          }
        )
    },[check])


    if(error) {
        return(
          <Container>
            <ButtonPurchase button={buttons} setcheck={setCheck} check={check}/>
            <CenterHandle CenterHandle>Error: {error.message}</CenterHandle>;
          </Container>
        )    
    }
    else if (!isLoaded) {
        return (
          <Container>
            <ButtonPurchase button={buttons} setcheck={setCheck} check={check}/>
            <CenterHandle>Loading...</CenterHandle>
          </Container>
        )
    }
    else if (purchases.length === 0)
        return (
          <Container>
            <ButtonPurchase button={buttons} setcheck={setCheck} check={check}/>
            <CenterHandle>
                <img src="https://deo.shopeemobile.com/shopee/shopee-pcmall-live-sg/assets/5fafbb923393b712b96488590b8f781f.png" alt="icon"/>
                <span>Chưa có đơn hàng</span>
            </CenterHandle>
          </Container>
        )
    else {
        return (
            <Container>
                <ButtonPurchase button={buttons} setcheck={setCheck} check={check}/>
                <Search>
                    <BiSearch style={{width: "23px", height: "23px", margin: "0 16px", color: "#555555CC"}}/>
                    <input className="input" placeholder="Tìm kiếm theo tên shop, ID đơn hàng hoặc tên sản phẩm"/>
                </Search>
                <Wrapper>
                {purchases.map(item =>(
                    <Content key={item.id}>
                        <HeaderContent>
                            <span className="storeName">Store</span>
                            <span className="status">{item.Status}</span>
                            <div className="date">
                                <span><label>Ngày Đặt Hàng :</label> {item.date_order}</span>
                                <span><label>Ngày Giao Hàng:</label> {item.date_ship}</span>
                            </div>
                        </HeaderContent>
                        <MainContent>
                            <div className="item">
                                <div className="wrapLeft">
                                    <img className="img" src={item.Image} alt="ảnh sản phẩm"/>
                                    <div className="wrapLeftChil">
                                        <span style={{fontSize: "16px"}}>{item.title}</span>
                                        <span className="classify">Phân loại hàng: {item.Classify}</span>
                                        <span>x {item.Amonut}</span>
                                    </div>
                                </div>
                                <div className="wrapRight">
                                    <span className="price">{item.Price}.000đ</span>
                                </div>
                            </div>
                        </MainContent>
                        <FooterContent>
                            <div className="wrap">
                                <span style={{fontSize: "16px"}}>Tổng số tiền: </span>
                                <span className="fullPrice">{item.Amonut * item.Price}.000đ</span>
                            </div>
                            <div className="action">
                                <ButtonPrimary>Mua Lại</ButtonPrimary>
                            </div>
                        </FooterContent>
                    </Content>
            ))}
                </Wrapper>
            </Container>
        )
    }
}
export default UserPurchase;
