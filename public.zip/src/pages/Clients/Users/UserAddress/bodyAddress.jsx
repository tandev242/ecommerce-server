import React, { useEffect, useState } from "react";
import styled from "styled-components";
import AddressDialog from "../../../../components/addressDialog";
import DeleteAddressDialog from "../../../../components/deleteAddressDialog";
import { BsPlusLg } from "react-icons/bs"
import { getAddressList, addAddress, getAddress, updateAddress, deleteAddress} from "../../../../data/addressData";

const Container = styled.div`
  width: 930px;
  margin-left: 20px;
  border-bottom: 1px solid ${({theme}) => theme.lineColor};
  height: 85px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`
const Title = styled.h1`
  font-size: 18px;
  font-weight: 500;
`

const ButtonPrimary = styled.button`
  height: 40px;
  width: 180px;
  background-color: ${({theme}) => theme.mainColor};
  cursor: pointer;
  border: none;
  border-radius: 2px;
  color: ${({theme}) => theme.textColorWhite};

  :hover {
    background-color: ${({theme}) => theme.btnPrimaryColorHover};
  }
`
const Wrapper = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
`

const CssIconPlus = {
    marginRight: "10px"
}


const ContainerBody = styled.div`
  display: flex;
  justify-content: space-between;
  flex-direction: column;
`

const Item = styled.div`
  margin-bottom: 12px;
`

const AddressCss = styled.div`
  margin-top: 12px;
  margin-left: 40px;
`

const WrapperBody = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-right: 20px;
`
const AddressItem = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  background: #fff;
  border-bottom: 1px dotted ${({theme}) => theme.lineColor};
`

const TextActionCss = styled.a`
  text-decoration: underline;
  color: ${({theme}) => theme.textColorBrown};
  margin-left: 20px;
  cursor: pointer;
`

const LabelBrown = styled.label`
  color: ${({theme}) => theme.textColorBrown};
  display: inline-block;
  width: 150px;
  height: 20px;
  max-width: 100%;
  text-align: right;
  margin-right: 27px;
`

const ButtonWhite = styled.button`
  height: 40px;
  width: 150px;
  color: ${({theme}) => theme.textColorBrown};
  background-color: ${({theme}) => theme.backGroundWhite};
  cursor: pointer;
  border: 1px solid ${({theme}) => theme.lineColor};
  border-radius: 2px;

  :hover {
    background-color: ${({theme}) => theme.backGroundBrown};
  }
`
const CenterHandle = styled.div`
  width: 970px;
  height: 340px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 20px;
`

const InfoAddress = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [addressList,setAddressList] = useState([]);
  const [showAddressDialog, setShowAddressDialog] = useState(false)
  const [showDeleteAddressDialog, setShowDeleteAddressDialog] = useState(false)
  const [formMode,setFormMode] = useState(true);
  const [addressId,setAddressId] = useState('');
  const [fullName,setFullName] = useState('');
  const [phone,setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [addressNote, setAddressNote] = useState('');

  const handleFullName = (event) => {
    setFullName(event.target.value);
  }

  const handlePhone = (event) => {
    setPhone(event.target.value);
  }

  const handleAddress = (event) => {
    setAddress(event.target.value);
  }

  const handleAddressNote = (event) => {
    setAddressNote(event.target.value);
  }

  const getList = async () => {
    try{
      setIsLoaded(true);
      const list = await getAddressList();
      setAddressList(list);
      setIsLoaded(false);
    } 
    catch(error) {
      setIsLoaded(false);
    }
  }

  const getOneAddress = async (id) => {
    try {
      setFormMode(false);
      setAddressId(id);
      const response = await getAddress(id);
      setFullName(response.fullName);
      setPhone(response.phone);
      setAddress(response.address);
      setAddressNote(response.addressNote);
      setShowAddressDialog(prev => !prev)
    }
    catch (error)
    {
      console.log(error);
    }
  } 

  const handleDelete = async (id) => {
    setAddressId(id);
    setShowDeleteAddressDialog(prev => !prev);
  }

  const deleteAddressHandle = async() => {
    try {
      await deleteAddress(addressId);
      getList();
      setShowDeleteAddressDialog(prev => !prev);
      } catch (error) {
      throw error
    }
  }

  const handleAdd = () => {
    setShowAddressDialog(prev => !prev);
    setFormMode(true);
    setFullName('');
    setPhone('');
    setAddress('');
    setAddressNote('');
  }

  const addAddressHandle = async () => {
    try {
      const addressvalue = {
        fullName,
        phone,
        address,
        addressNote
      }
      if(formMode) {
        await addAddress(addressvalue);
        getList();
        setShowAddressDialog(prev => !prev);
        setFullName('');
        setPhone('');
        setAddress('');
        setAddressNote('');
      }
      else {
        await updateAddress(addressId, addressvalue);
        getList();
        setShowAddressDialog(prev => !prev);
        setFullName('');
        setPhone('');
        setAddress('');
        setAddressNote('');
      }
    } catch (error) {
      
    }
  }

    useEffect(()=> { 
      getList();
  },[])


  return (
    <React.Fragment>
      <div>
          <Container>
            <Title>Địa Chỉ Của Tôi</Title>
            <ButtonPrimary onClick={handleAdd}>
                <Wrapper>
                    <BsPlusLg style={CssIconPlus}/>
                    <span>Thêm Địa Chỉ Mới</span>
                </Wrapper>
            </ButtonPrimary>
          </Container>
      </div>
      <div>
          { (isLoaded) ? (<CenterHandle>Loading...</CenterHandle>) : 
            (addressList.length === 0) ? 
            (
              <CenterHandle>Không có địa chỉ</CenterHandle>
            ) 
            :
            (
              <React.Fragment>
                {addressList.map(item => (
                  <AddressItem key={item.id}>
                    <AddressCss>
                      <Item>
                        <LabelBrown>Họ và tên</LabelBrown>
                        <span style={{fontSize: "16px"}}>{item.fullName}</span>
                      </Item> 
                      <Item>
                        <LabelBrown>Số điện thoại</LabelBrown>
                        <span>{item.phone}</span>
                      </Item>
                      <Item>
                        <LabelBrown>Địa chỉ</LabelBrown>
                        <span>{item.address}</span>
                      </Item>
                      <Item>
                        <LabelBrown>Địa chỉ cụ thể</LabelBrown>
                        <span>{item.addressNote}</span>
                      </Item>
                    </AddressCss> 
                    <WrapperBody>
                      <Item>
                        <TextActionCss onClick={() => getOneAddress(item.id)} >Cập nhật</TextActionCss>
                        <TextActionCss onClick={() => handleDelete(item.id)}>Xóa</TextActionCss>
                      </Item>
                      <Item>
                        <ButtonWhite>Thiết Lập Mặc Định</ButtonWhite>
                      </Item>
                    </WrapperBody>
                  </AddressItem>
                ))}
              </React.Fragment>
            )
          }
      </div>
      <div>
          <AddressDialog
            formMode={formMode}
            fullName={fullName}
            phone={phone}
            address={address}
            addressNote={addressNote}
            changeFullName={handleFullName}
            changePhone={handlePhone}
            changeAddress={handleAddress}
            changeAddressNote={handleAddressNote}
            addAddress={addAddressHandle}
            showAddressDialog={showAddressDialog} 
            setShowAddressDialog={setShowAddressDialog}/>
          <DeleteAddressDialog 
            deleteAddress={deleteAddressHandle}
            showDeleteAddressDialog={showDeleteAddressDialog} 
            setShowDeleteAddressDialog={setShowDeleteAddressDialog}/>
      </div>
    </React.Fragment>
  )
}

const BodyAddress = () => {
    return(
        <ContainerBody>
          <InfoAddress/>
        </ContainerBody>
    )
}

export default BodyAddress