import React,{useState,useEffect} from "react";
import styled from "styled-components";
import Radiobtn from "../../../../components/radioBtn";
import Selectdate from "../../../../components/selectDate";
import Selectmonth from "../../../../components/selectMonth";
import Selectyear from "../../../../components/selectYear";
import { collection, onSnapshot, query } from "firebase/firestore";
import { db } from "../../../../firebase/firebase-config";
import { async } from "@firebase/util";
import { updateProfile } from "firebase/auth"
import uploadFile from "../../../../firebase/uploadFile";

const UserInfo = styled.div`
  margin-top: 22px;
`

const ItemUserInfo = styled.div`
  margin-bottom: 25px;
`

const LabelBrown = styled.label`
  color: ${({theme}) => theme.textColorBrown};
  display: inline-block;
  width: 150px;
  height: 20px;
  max-width: 100%;
  text-align: right;
  margin-right: 27px;
`

const InputText = styled.input`
  height: 35px;
  width: 450px;
  background-color: ${({theme}) => theme.backGroundWhite};
  border: 1px solid ${({theme}) => theme.lineColor};
  border-radius: 2px;
  padding-left: 10px;
`

const TextActionCss = styled.a`
  color: ${({theme}) => theme.textColorBlue};
  margin-left: 10px;
`

const ButtonPrimary = styled.button`
  height: 40px;
  width: 70px;
  background-color: ${({theme}) => theme.mainColor};
  cursor: pointer;
  border: none;
  border-radius: 2px;
  color: ${({theme}) => theme.textColorWhite};

  :hover {
    background-color: ${({theme}) => theme.btnPrimaryColorHover};
  }
`

const ChooseImg = styled.section`
  height: 250px;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 30px;
  margin-left: 50px;
  padding-left: 40px;
  border-left: 1px solid ${({theme}) => theme.lineColor};

  .wrapChooseImg{
    position: relative; 

    &:hover{
      button{
        background-color: ${({theme}) => theme.backGroundBrown};
      }
    }
  }

  .chooseFile{
    position: relative;
    max-width: 100px;
    height: 40px;
    z-index: 2;
    cursor: pointer;
    opacity: 0;
  }
`

const ProfileImage = styled.img`
    height: 6rem;
    width: 6rem;
    border-radius: 5rem;
    margin-top: 15px;
    margin-bottom: 15px;
`

const ButtonWhite = styled.button`
  position: absolute;
  top:0;
  left: 0;
  height: 40px;
  width: 100px;
  z-index: 1;
  background-color: ${({theme}) => theme.backGroundWhite};
  cursor: pointer;
  border: 1px solid ${({theme}) => theme.lineColor};
  border-radius: 2px;
`
const CenterHandle = styled.div`
  width: 970px;
  height: 540px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 20px;
`
const rdi = ["Nam", "Nữ", "Khác"]
const Profile = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [profile,setProfile] = useState([]);
  const [radios] = useState(rdi);
  const [file, setFile] = useState(null);
  const [photoURL, setPhotoURL] = useState(null);
  
  const handleChange = (e) => {
    const file = e.target.files[0]
    if(file){
      setFile(file)
      setPhotoURL(URL.createObjectURL(file))
    }
  }

  // const handleSubmit = async (e) => {
  //   e.preventDefault()
  //   setLoading(true)

  //   let profileObj = {...profile}
  //   let imagesObj = {name: avatar}

  //   try {
  //     if(file){
  //       const imageName = "." + file?.name?.split(".")?.pop()
  //       const url = await uploadFile(file,`profile/${imageName}`)

  //       profileObj = {...profileObj, photoURL: url}
  //       imagesObj = {...imagesObj, avatar: url}
  //     }

  //     await updateProfile(profileObj)
      

  //   }
  //   catch {

  //   }
  // }

  useEffect(()=> { 
      const profileRef = collection(db, "users");
      const q = query(profileRef);
      onSnapshot(q, (snapshot) => {
        const profiles = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }))
        setIsLoaded(true);
        setProfile(profiles);
      })
  },[])
 
  if (!isLoaded) {
    return <CenterHandle>Loading...</CenterHandle>;
  }
  else {
    return (
      <React.Fragment>
        {profile.map(item => (
          <React.Fragment key={item.id}>
            <UserInfo>
              <ItemUserInfo>
                <LabelBrown>Tên Đăng Nhập</LabelBrown>
                <span>{item.nameLogin}</span>
              </ItemUserInfo>
              <ItemUserInfo>
                <LabelBrown>Tên</LabelBrown>
                <InputText defaultValue={item.name}/>
              </ItemUserInfo>
              <ItemUserInfo>
                <LabelBrown>Email</LabelBrown>
                <span>{item.email}</span>
                <TextActionCss href="#">Thay Đổi</TextActionCss>
              </ItemUserInfo>
              <ItemUserInfo>
                <LabelBrown>Số Điện Thoại</LabelBrown>
                <span>{item.phone}</span>
                <TextActionCss href="#">Thay Đổi</TextActionCss>  
              </ItemUserInfo>
              <ItemUserInfo>
                <LabelBrown>Tên Shop</LabelBrown>
                <InputText defaultValue={item.nameShop}/>
              </ItemUserInfo>
              <ItemUserInfo>
                <LabelBrown>Giới Tính</LabelBrown>
                <Radiobtn values={radios} check={item.gender}/>
              </ItemUserInfo>
              <ItemUserInfo>
                <LabelBrown>Ngày Sinh</LabelBrown>
                <Selectdate value={item.birthDay.date}/>
                <Selectmonth value={item.birthDay.month}/>
                <Selectyear value={item.birthDay.year}/>
              </ItemUserInfo>
              <ItemUserInfo>
               <LabelBrown/>
               <ButtonPrimary>Lưu</ButtonPrimary>
              </ItemUserInfo>
            </UserInfo>
            <ChooseImg>
              <ProfileImage src={photoURL || item.avatar}/>
              <div className="wrapChooseImg">
                <input className="chooseFile" type="file" accept=".jpg,.jpeg,.png" onChange={handleChange}/>
                <ButtonWhite>Chọn Ảnh</ButtonWhite>
              </div>
              <label style={{"color": "#555555CC", "marginTop": "15px"}}>Dụng lượng file tối đa 1 MB<br/>Định dạng:.JPEG, .PNG</label>
            </ChooseImg>
          </React.Fragment>
        ))}
      </React.Fragment>
    );
  }
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
`

const BodyUserInfo = () => {
    return(
      <Container>
        <Profile/>
      </Container>
    )
}

export default BodyUserInfo