import React from "react";
import styled from "styled-components";

const Container = styled.div`
  display: flex;
`

const Item = styled.div`
  margin-bottom: 25px;
`

const ChangePassCss = styled.div`
  margin-left: 100px;
  margin-top: 22px;
`

const TextActionCss = styled.a`
  color: ${({theme}) => theme.textColorBrown};
  margin-left: 20px;
  cursor: pointer;
`

const LabelBrown = styled.label`
  color: ${({theme}) => theme.textColorBrown};
  display: inline-block;
  width: 150px;
  height: 20px;
  max-width: 100%;
  text-align: right;
  margin-right: 27px;
`
const InputText = styled.input`
  height: 35px;
  width: 350px;
  background-color: ${({theme}) => theme.backGroundWhite};
  border: 1px solid ${({theme}) => theme.lineColor};
  border-radius: 2px;
  padding-left: 10px;
`

const ButtonPrimary = styled.button`
  height: 40px;
  width: 100px;
  background-color: ${({theme}) => theme.mainColor};
  cursor: pointer;
  border: none;
  border-radius: 2px;
  color: ${({theme}) => theme.textColorWhite};

  :hover {
    background-color: ${({theme}) => theme.btnPrimaryColorHover};
  }
`

const InfoChangePass = () => {
  return (
    <ChangePassCss>
      <Item>
        <LabelBrown>Mật Khẩu Hiện Tại</LabelBrown>
        <InputText/>
        <TextActionCss>Quên mật khẩu?</TextActionCss>
      </Item>
      <Item>
        <LabelBrown>Mật Khẩu Mới</LabelBrown>
        <InputText/>
      </Item>
      <Item>
        <LabelBrown>Xác Nhận Mật Khẩu</LabelBrown>
        <InputText/>
      </Item>
      <Item>
        <LabelBrown/>
        <ButtonPrimary>Xác Nhận</ButtonPrimary>
      </Item>     
    </ChangePassCss>
  )
}

const BodyChangePass = () => {
    return(
      <Container>
        <InfoChangePass/>
      </Container>
    )
}

export default BodyChangePass