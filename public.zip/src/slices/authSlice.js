import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import authApi from "../apis/authApi";


export const signin = createAsyncThunk("auth/signin", async (user) => {
  const response = await authApi.signin(user);
  return response;
});

export const signup = createAsyncThunk("auth/signup", async (user) => {
  const response = await authApi.signup(user);
  return response;
});

export const isUserLoggedIn = createAsyncThunk("auth/isUserLoggedIn", async () => {
  const response = await authApi.isUserLoggedIn();
  return response;
});

export const authSlice = createSlice({
  name: "auth",
  initialState: {
    user: null,
    loading: false,
    isAuthenticated: false,
    error: null
  },
  extraReducers: {
    [signin.pending]: (state) => {
      state.loading = true;
    },
    [signin.rejected]: (state, action) => {
      state.loading = false;
      state.error = action.error;
    },
    [signin.fulfilled]: (state, action) => {
      console.log(action)
      state.loading = false;
      state.user = action.payload.data.user;
      state.isAuthenticated = true;
      localStorage.setItem("token", action.payload.data.token);
    },
    [signup.pending]: (state) => {
      state.loading = true;
    },
    [signup.rejected]: (state, action) => {
      state.loading = false;
      state.error = action.error;
    },
    [signup.fulfilled]: (state, action) => {
      state.loading = false;
    },
    [isUserLoggedIn.pending]: (state) => {
      state.loading = true;
    },
    [isUserLoggedIn.rejected]: (state, action) => {
      state.loading = false;
      state.error = action.error;
    },
    [isUserLoggedIn.fulfilled]: (state, action) => {
      state.user =  action.payload.data.user;
      state.isAuthenticated = true;
    }
  }
})

export default authSlice.reducer;
