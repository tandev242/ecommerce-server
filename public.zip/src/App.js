import "./App.css";
import "./css//base.css";
import "./css/style.css";
import "./css/grid.css";
import "./css/signs.css";
import { Routes, Route } from "react-router-dom";
import Cart from "./pages/Clients/Cart/cart";
import Support from "./pages/Clients/Cart/support";
import Home from "./pages/Clients/Home/home";
import Signin from "./pages/Clients/Signs/signIn";
import Signup from "./pages/Clients/Signs/signUp";
import SearchHome from "./pages/Clients/SearchHome/searchHome";
import ProductDetail from "./pages/Clients/Detail/productDetails";
import User from "./pages/Clients/Users/user";
import PageProducts from "./pages/Clients/Home/HomeContent/pageProducts";
import Dashboard from "./pages/Admin/Dashbo/Dashboard";
import ProductList from "./pages/Admin/List/productList";
import Brand from "./pages/Admin/List/BrandManagement";
import AddProduct from "./pages/Admin/Add/addProduct";
import AddTrademark from "./pages/Admin/Add/addTrademark";
import OrderList from "./pages/Admin/List/OrderList";
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { isUserLoggedIn } from './slices/authSlice';


//---------------------
function App() {
  const { isAuthenticated } = useSelector(state => state.auth)
  const dispatch = useDispatch()
  useEffect(() => {
    const fetchUser = () => {
      dispatch(isUserLoggedIn())
    }
    fetchUser()
  }, [isAuthenticated]);

  return (
    // <AuthProvider>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/page_products/*" element={<PageProducts />} />
      <Route path="/cart/*" element={<Cart />} />
      <Route path="/support/*" element={<Support />} />
      <Route path="/signin/*" element={<Signin />} />
      <Route path="/signup/*" element={<Signup />} />
      <Route path="/searchhome/*" element={<SearchHome />} />
      <Route path="/detail/:id" element={<ProductDetail />} />
      <Route path="/user/*" element={<User />} />
      <Route path="/admin/*" element={<Dashboard />} />
      <Route path="/listproduct/*" element={<ProductList />} />
      <Route path="/brand/*" element={<Brand />} />
      <Route path="/addproduct/*" element={<AddProduct />} />
      <Route path="/addtrademark/*" element={<AddTrademark />} />
      <Route path="/listorder/*" element={<OrderList />} />
    </Routes>
    // </AuthProvider>
    //<FirebaseApp></FirebaseApp>
  );
}

export default App;
