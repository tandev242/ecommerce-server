import axios from "./axios"

const authApi = {
  signin: (user) => {
    const url = "/auth/signin";
    return axios.post(url, user)
  },
  signup: (user) => {
    const url = "/auth/signup";
    return axios.post(url, user)
  },
  isUserLoggedIn: () => {
    const url = "/auth/isUserLoggedIn";
    return axios.post(url)
  }
}

export default authApi
