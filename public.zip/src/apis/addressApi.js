import axios from "./axios"

const addressApi = {
  getAddress: () => {
    const url = "/deliveryInfo/get";
    return axios.post(url, user)
  },
  addAddress: (user) => {
    const url = "/deliveryInfo/add";
    return axios.post(url, user)
  }
}
    
export default addressApi
