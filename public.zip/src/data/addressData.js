import app from "../firebase/firebase-config";
import Address from "../models/address"
import 'firebase/compat/firestore';

const firestore = app.firestore();

export const getAddressList = async () => {
    try {
        const response = await firestore.collection('address');
        const data = await response.get();
        let array = []
        data.forEach(doc => {
            const address = new Address(
                doc.id,
                doc.data().fullName,
                doc.data().phone,
                doc.data().address,
                doc.data().addressNote,
            );

            array.push(address);
        });
        return array;
    } catch (error) {
        throw error
    }
}

export const addAddress = async (address) => {
    try {
        await firestore.collection('address').doc().set(address);
    } catch (error) {
        throw error;
    }
}

export const getAddress = async (id) => {
    try {
        const address = await firestore.collection('address').doc(id);
        const data = await address.get();
        return data.data();
    } catch (error) {
        throw error;
    }
}

export const updateAddress = async (id, data) => {
    try {
        const address = await firestore.collection('address').doc(id);
        await address.update(data);
    } catch (error) {
        throw error;
    }
}

export const deleteAddress = async (id) => {
    try {
        await firestore.collection('address').doc(id).delete();
    } catch (error) {

    }
}